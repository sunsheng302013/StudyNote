/**
 * Copyright(C) 2018 Hangzhou Differsoft Co., Ltd. All rights reserved.
 *
 */
package com.cq.service;

import java.util.List;

import com.cq.model.DepartPosition;

/**
 * @since 2018年8月28日 下午6:41:11
 * @author chengq
 *
 */
public interface DepartPositionService {

    public List<DepartPosition> getPosition();
}
