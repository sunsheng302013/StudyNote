package com.cq.dao;

public interface DepartInfoDao {

}