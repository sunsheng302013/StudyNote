package com.cq.dao;

public interface PositionInfoDao {
}