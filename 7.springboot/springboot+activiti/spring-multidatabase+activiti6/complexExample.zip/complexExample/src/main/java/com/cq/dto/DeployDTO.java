/**
 * Copyright(C) 2018 Hangzhou Differsoft Co., Ltd. All rights reserved.
 *
 */
package com.cq.dto;

/**
 * 部署流程生成XMl文件定义文件
 * 
 * @since 2018年8月24日 下午1:42:23
 * @author huangyi
 *
 */
public class DeployDTO {

}
