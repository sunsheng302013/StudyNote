springboot三个数据源切换
数据源切换的主要方法是com.cq.common.datasource中的四个方法
DataSourceConfig类中主要是配置数据源，从application.properties中读取数据源配置信息生成数据源DataSource
在这个类中设置默认数据库，即不主动切库时使用的数据库

DataSourceContextHolder类切换数据源，清楚数据源名

DynamicDataSourceAspect：AOP切面类，通过自定义注解实现数据源动态切换
在注解DS注入的方法执行前切库，方法执行之后清除数据源名

DS：切库注解

activiti流程表放在activiti_flow数据库中，在项目第一次启动时会自动在数据库中生成28张表
数据库的配置在OaPrimaryDataSourceConfig类中

j_depart_info中是需要建立的业务表