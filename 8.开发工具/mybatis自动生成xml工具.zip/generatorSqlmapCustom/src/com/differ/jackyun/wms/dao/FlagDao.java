package com.differ.jackyun.wms.dao;

public interface FlagDao {

}