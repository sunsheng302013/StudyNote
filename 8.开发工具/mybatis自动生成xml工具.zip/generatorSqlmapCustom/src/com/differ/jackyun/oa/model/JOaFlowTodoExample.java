package com.differ.jackyun.oa.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JOaFlowTodoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public JOaFlowTodoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNull() {
            addCriterion("flow_id is null");
            return (Criteria) this;
        }

        public Criteria andFlowIdIsNotNull() {
            addCriterion("flow_id is not null");
            return (Criteria) this;
        }

        public Criteria andFlowIdEqualTo(Long value) {
            addCriterion("flow_id =", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotEqualTo(Long value) {
            addCriterion("flow_id <>", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThan(Long value) {
            addCriterion("flow_id >", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdGreaterThanOrEqualTo(Long value) {
            addCriterion("flow_id >=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThan(Long value) {
            addCriterion("flow_id <", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdLessThanOrEqualTo(Long value) {
            addCriterion("flow_id <=", value, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdIn(List<Long> values) {
            addCriterion("flow_id in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotIn(List<Long> values) {
            addCriterion("flow_id not in", values, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdBetween(Long value1, Long value2) {
            addCriterion("flow_id between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andFlowIdNotBetween(Long value1, Long value2) {
            addCriterion("flow_id not between", value1, value2, "flowId");
            return (Criteria) this;
        }

        public Criteria andFormIdIsNull() {
            addCriterion("form_id is null");
            return (Criteria) this;
        }

        public Criteria andFormIdIsNotNull() {
            addCriterion("form_id is not null");
            return (Criteria) this;
        }

        public Criteria andFormIdEqualTo(Long value) {
            addCriterion("form_id =", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdNotEqualTo(Long value) {
            addCriterion("form_id <>", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdGreaterThan(Long value) {
            addCriterion("form_id >", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdGreaterThanOrEqualTo(Long value) {
            addCriterion("form_id >=", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdLessThan(Long value) {
            addCriterion("form_id <", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdLessThanOrEqualTo(Long value) {
            addCriterion("form_id <=", value, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdIn(List<Long> values) {
            addCriterion("form_id in", values, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdNotIn(List<Long> values) {
            addCriterion("form_id not in", values, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdBetween(Long value1, Long value2) {
            addCriterion("form_id between", value1, value2, "formId");
            return (Criteria) this;
        }

        public Criteria andFormIdNotBetween(Long value1, Long value2) {
            addCriterion("form_id not between", value1, value2, "formId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNull() {
            addCriterion("task_id is null");
            return (Criteria) this;
        }

        public Criteria andTaskIdIsNotNull() {
            addCriterion("task_id is not null");
            return (Criteria) this;
        }

        public Criteria andTaskIdEqualTo(String value) {
            addCriterion("task_id =", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotEqualTo(String value) {
            addCriterion("task_id <>", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThan(String value) {
            addCriterion("task_id >", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdGreaterThanOrEqualTo(String value) {
            addCriterion("task_id >=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThan(String value) {
            addCriterion("task_id <", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLessThanOrEqualTo(String value) {
            addCriterion("task_id <=", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdLike(String value) {
            addCriterion("task_id like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotLike(String value) {
            addCriterion("task_id not like", value, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdIn(List<String> values) {
            addCriterion("task_id in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotIn(List<String> values) {
            addCriterion("task_id not in", values, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdBetween(String value1, String value2) {
            addCriterion("task_id between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andTaskIdNotBetween(String value1, String value2) {
            addCriterion("task_id not between", value1, value2, "taskId");
            return (Criteria) this;
        }

        public Criteria andFlowTitleIsNull() {
            addCriterion("flow_title is null");
            return (Criteria) this;
        }

        public Criteria andFlowTitleIsNotNull() {
            addCriterion("flow_title is not null");
            return (Criteria) this;
        }

        public Criteria andFlowTitleEqualTo(String value) {
            addCriterion("flow_title =", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleNotEqualTo(String value) {
            addCriterion("flow_title <>", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleGreaterThan(String value) {
            addCriterion("flow_title >", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleGreaterThanOrEqualTo(String value) {
            addCriterion("flow_title >=", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleLessThan(String value) {
            addCriterion("flow_title <", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleLessThanOrEqualTo(String value) {
            addCriterion("flow_title <=", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleLike(String value) {
            addCriterion("flow_title like", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleNotLike(String value) {
            addCriterion("flow_title not like", value, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleIn(List<String> values) {
            addCriterion("flow_title in", values, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleNotIn(List<String> values) {
            addCriterion("flow_title not in", values, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleBetween(String value1, String value2) {
            addCriterion("flow_title between", value1, value2, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andFlowTitleNotBetween(String value1, String value2) {
            addCriterion("flow_title not between", value1, value2, "flowTitle");
            return (Criteria) this;
        }

        public Criteria andPriorityIsNull() {
            addCriterion("priority is null");
            return (Criteria) this;
        }

        public Criteria andPriorityIsNotNull() {
            addCriterion("priority is not null");
            return (Criteria) this;
        }

        public Criteria andPriorityEqualTo(Byte value) {
            addCriterion("priority =", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotEqualTo(Byte value) {
            addCriterion("priority <>", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityGreaterThan(Byte value) {
            addCriterion("priority >", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityGreaterThanOrEqualTo(Byte value) {
            addCriterion("priority >=", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityLessThan(Byte value) {
            addCriterion("priority <", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityLessThanOrEqualTo(Byte value) {
            addCriterion("priority <=", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityIn(List<Byte> values) {
            addCriterion("priority in", values, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotIn(List<Byte> values) {
            addCriterion("priority not in", values, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityBetween(Byte value1, Byte value2) {
            addCriterion("priority between", value1, value2, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotBetween(Byte value1, Byte value2) {
            addCriterion("priority not between", value1, value2, "priority");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Byte value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Byte value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Byte value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Byte value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Byte value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Byte> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Byte> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Byte value1, Byte value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andFlowStatusIsNull() {
            addCriterion("flow_status is null");
            return (Criteria) this;
        }

        public Criteria andFlowStatusIsNotNull() {
            addCriterion("flow_status is not null");
            return (Criteria) this;
        }

        public Criteria andFlowStatusEqualTo(Byte value) {
            addCriterion("flow_status =", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusNotEqualTo(Byte value) {
            addCriterion("flow_status <>", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusGreaterThan(Byte value) {
            addCriterion("flow_status >", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("flow_status >=", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusLessThan(Byte value) {
            addCriterion("flow_status <", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusLessThanOrEqualTo(Byte value) {
            addCriterion("flow_status <=", value, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusIn(List<Byte> values) {
            addCriterion("flow_status in", values, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusNotIn(List<Byte> values) {
            addCriterion("flow_status not in", values, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusBetween(Byte value1, Byte value2) {
            addCriterion("flow_status between", value1, value2, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andFlowStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("flow_status not between", value1, value2, "flowStatus");
            return (Criteria) this;
        }

        public Criteria andStepOrderIsNull() {
            addCriterion("step_order is null");
            return (Criteria) this;
        }

        public Criteria andStepOrderIsNotNull() {
            addCriterion("step_order is not null");
            return (Criteria) this;
        }

        public Criteria andStepOrderEqualTo(Integer value) {
            addCriterion("step_order =", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderNotEqualTo(Integer value) {
            addCriterion("step_order <>", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderGreaterThan(Integer value) {
            addCriterion("step_order >", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderGreaterThanOrEqualTo(Integer value) {
            addCriterion("step_order >=", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderLessThan(Integer value) {
            addCriterion("step_order <", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderLessThanOrEqualTo(Integer value) {
            addCriterion("step_order <=", value, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderIn(List<Integer> values) {
            addCriterion("step_order in", values, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderNotIn(List<Integer> values) {
            addCriterion("step_order not in", values, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderBetween(Integer value1, Integer value2) {
            addCriterion("step_order between", value1, value2, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andStepOrderNotBetween(Integer value1, Integer value2) {
            addCriterion("step_order not between", value1, value2, "stepOrder");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameIsNull() {
            addCriterion("this_node_name is null");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameIsNotNull() {
            addCriterion("this_node_name is not null");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameEqualTo(String value) {
            addCriterion("this_node_name =", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameNotEqualTo(String value) {
            addCriterion("this_node_name <>", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameGreaterThan(String value) {
            addCriterion("this_node_name >", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameGreaterThanOrEqualTo(String value) {
            addCriterion("this_node_name >=", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameLessThan(String value) {
            addCriterion("this_node_name <", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameLessThanOrEqualTo(String value) {
            addCriterion("this_node_name <=", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameLike(String value) {
            addCriterion("this_node_name like", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameNotLike(String value) {
            addCriterion("this_node_name not like", value, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameIn(List<String> values) {
            addCriterion("this_node_name in", values, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameNotIn(List<String> values) {
            addCriterion("this_node_name not in", values, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameBetween(String value1, String value2) {
            addCriterion("this_node_name between", value1, value2, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andThisNodeNameNotBetween(String value1, String value2) {
            addCriterion("this_node_name not between", value1, value2, "thisNodeName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdIsNull() {
            addCriterion("start_company_id is null");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdIsNotNull() {
            addCriterion("start_company_id is not null");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdEqualTo(Long value) {
            addCriterion("start_company_id =", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdNotEqualTo(Long value) {
            addCriterion("start_company_id <>", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdGreaterThan(Long value) {
            addCriterion("start_company_id >", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdGreaterThanOrEqualTo(Long value) {
            addCriterion("start_company_id >=", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdLessThan(Long value) {
            addCriterion("start_company_id <", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdLessThanOrEqualTo(Long value) {
            addCriterion("start_company_id <=", value, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdIn(List<Long> values) {
            addCriterion("start_company_id in", values, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdNotIn(List<Long> values) {
            addCriterion("start_company_id not in", values, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdBetween(Long value1, Long value2) {
            addCriterion("start_company_id between", value1, value2, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyIdNotBetween(Long value1, Long value2) {
            addCriterion("start_company_id not between", value1, value2, "startCompanyId");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameIsNull() {
            addCriterion("start_company_name is null");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameIsNotNull() {
            addCriterion("start_company_name is not null");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameEqualTo(String value) {
            addCriterion("start_company_name =", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameNotEqualTo(String value) {
            addCriterion("start_company_name <>", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameGreaterThan(String value) {
            addCriterion("start_company_name >", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameGreaterThanOrEqualTo(String value) {
            addCriterion("start_company_name >=", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameLessThan(String value) {
            addCriterion("start_company_name <", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameLessThanOrEqualTo(String value) {
            addCriterion("start_company_name <=", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameLike(String value) {
            addCriterion("start_company_name like", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameNotLike(String value) {
            addCriterion("start_company_name not like", value, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameIn(List<String> values) {
            addCriterion("start_company_name in", values, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameNotIn(List<String> values) {
            addCriterion("start_company_name not in", values, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameBetween(String value1, String value2) {
            addCriterion("start_company_name between", value1, value2, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartCompanyNameNotBetween(String value1, String value2) {
            addCriterion("start_company_name not between", value1, value2, "startCompanyName");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdIsNull() {
            addCriterion("start_depart_id is null");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdIsNotNull() {
            addCriterion("start_depart_id is not null");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdEqualTo(Long value) {
            addCriterion("start_depart_id =", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdNotEqualTo(Long value) {
            addCriterion("start_depart_id <>", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdGreaterThan(Long value) {
            addCriterion("start_depart_id >", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdGreaterThanOrEqualTo(Long value) {
            addCriterion("start_depart_id >=", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdLessThan(Long value) {
            addCriterion("start_depart_id <", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdLessThanOrEqualTo(Long value) {
            addCriterion("start_depart_id <=", value, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdIn(List<Long> values) {
            addCriterion("start_depart_id in", values, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdNotIn(List<Long> values) {
            addCriterion("start_depart_id not in", values, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdBetween(Long value1, Long value2) {
            addCriterion("start_depart_id between", value1, value2, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartIdNotBetween(Long value1, Long value2) {
            addCriterion("start_depart_id not between", value1, value2, "startDepartId");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameIsNull() {
            addCriterion("start_depart_name is null");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameIsNotNull() {
            addCriterion("start_depart_name is not null");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameEqualTo(String value) {
            addCriterion("start_depart_name =", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameNotEqualTo(String value) {
            addCriterion("start_depart_name <>", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameGreaterThan(String value) {
            addCriterion("start_depart_name >", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameGreaterThanOrEqualTo(String value) {
            addCriterion("start_depart_name >=", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameLessThan(String value) {
            addCriterion("start_depart_name <", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameLessThanOrEqualTo(String value) {
            addCriterion("start_depart_name <=", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameLike(String value) {
            addCriterion("start_depart_name like", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameNotLike(String value) {
            addCriterion("start_depart_name not like", value, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameIn(List<String> values) {
            addCriterion("start_depart_name in", values, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameNotIn(List<String> values) {
            addCriterion("start_depart_name not in", values, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameBetween(String value1, String value2) {
            addCriterion("start_depart_name between", value1, value2, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartDepartNameNotBetween(String value1, String value2) {
            addCriterion("start_depart_name not between", value1, value2, "startDepartName");
            return (Criteria) this;
        }

        public Criteria andStartUserIdIsNull() {
            addCriterion("start_user_id is null");
            return (Criteria) this;
        }

        public Criteria andStartUserIdIsNotNull() {
            addCriterion("start_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andStartUserIdEqualTo(Long value) {
            addCriterion("start_user_id =", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdNotEqualTo(Long value) {
            addCriterion("start_user_id <>", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdGreaterThan(Long value) {
            addCriterion("start_user_id >", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("start_user_id >=", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdLessThan(Long value) {
            addCriterion("start_user_id <", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdLessThanOrEqualTo(Long value) {
            addCriterion("start_user_id <=", value, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdIn(List<Long> values) {
            addCriterion("start_user_id in", values, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdNotIn(List<Long> values) {
            addCriterion("start_user_id not in", values, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdBetween(Long value1, Long value2) {
            addCriterion("start_user_id between", value1, value2, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserIdNotBetween(Long value1, Long value2) {
            addCriterion("start_user_id not between", value1, value2, "startUserId");
            return (Criteria) this;
        }

        public Criteria andStartUserNameIsNull() {
            addCriterion("start_user_name is null");
            return (Criteria) this;
        }

        public Criteria andStartUserNameIsNotNull() {
            addCriterion("start_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andStartUserNameEqualTo(String value) {
            addCriterion("start_user_name =", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameNotEqualTo(String value) {
            addCriterion("start_user_name <>", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameGreaterThan(String value) {
            addCriterion("start_user_name >", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("start_user_name >=", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameLessThan(String value) {
            addCriterion("start_user_name <", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameLessThanOrEqualTo(String value) {
            addCriterion("start_user_name <=", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameLike(String value) {
            addCriterion("start_user_name like", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameNotLike(String value) {
            addCriterion("start_user_name not like", value, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameIn(List<String> values) {
            addCriterion("start_user_name in", values, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameNotIn(List<String> values) {
            addCriterion("start_user_name not in", values, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameBetween(String value1, String value2) {
            addCriterion("start_user_name between", value1, value2, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartUserNameNotBetween(String value1, String value2) {
            addCriterion("start_user_name not between", value1, value2, "startUserName");
            return (Criteria) this;
        }

        public Criteria andStartDateIsNull() {
            addCriterion("start_date is null");
            return (Criteria) this;
        }

        public Criteria andStartDateIsNotNull() {
            addCriterion("start_date is not null");
            return (Criteria) this;
        }

        public Criteria andStartDateEqualTo(Date value) {
            addCriterion("start_date =", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotEqualTo(Date value) {
            addCriterion("start_date <>", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateGreaterThan(Date value) {
            addCriterion("start_date >", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateGreaterThanOrEqualTo(Date value) {
            addCriterion("start_date >=", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateLessThan(Date value) {
            addCriterion("start_date <", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateLessThanOrEqualTo(Date value) {
            addCriterion("start_date <=", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateIn(List<Date> values) {
            addCriterion("start_date in", values, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotIn(List<Date> values) {
            addCriterion("start_date not in", values, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateBetween(Date value1, Date value2) {
            addCriterion("start_date between", value1, value2, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotBetween(Date value1, Date value2) {
            addCriterion("start_date not between", value1, value2, "startDate");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameIsNull() {
            addCriterion("send_node_name is null");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameIsNotNull() {
            addCriterion("send_node_name is not null");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameEqualTo(String value) {
            addCriterion("send_node_name =", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameNotEqualTo(String value) {
            addCriterion("send_node_name <>", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameGreaterThan(String value) {
            addCriterion("send_node_name >", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameGreaterThanOrEqualTo(String value) {
            addCriterion("send_node_name >=", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameLessThan(String value) {
            addCriterion("send_node_name <", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameLessThanOrEqualTo(String value) {
            addCriterion("send_node_name <=", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameLike(String value) {
            addCriterion("send_node_name like", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameNotLike(String value) {
            addCriterion("send_node_name not like", value, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameIn(List<String> values) {
            addCriterion("send_node_name in", values, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameNotIn(List<String> values) {
            addCriterion("send_node_name not in", values, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameBetween(String value1, String value2) {
            addCriterion("send_node_name between", value1, value2, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendNodeNameNotBetween(String value1, String value2) {
            addCriterion("send_node_name not between", value1, value2, "sendNodeName");
            return (Criteria) this;
        }

        public Criteria andSendTypeIsNull() {
            addCriterion("send_type is null");
            return (Criteria) this;
        }

        public Criteria andSendTypeIsNotNull() {
            addCriterion("send_type is not null");
            return (Criteria) this;
        }

        public Criteria andSendTypeEqualTo(Byte value) {
            addCriterion("send_type =", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeNotEqualTo(Byte value) {
            addCriterion("send_type <>", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeGreaterThan(Byte value) {
            addCriterion("send_type >", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("send_type >=", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeLessThan(Byte value) {
            addCriterion("send_type <", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeLessThanOrEqualTo(Byte value) {
            addCriterion("send_type <=", value, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeIn(List<Byte> values) {
            addCriterion("send_type in", values, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeNotIn(List<Byte> values) {
            addCriterion("send_type not in", values, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeBetween(Byte value1, Byte value2) {
            addCriterion("send_type between", value1, value2, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("send_type not between", value1, value2, "sendType");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdIsNull() {
            addCriterion("send_depart_id is null");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdIsNotNull() {
            addCriterion("send_depart_id is not null");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdEqualTo(Long value) {
            addCriterion("send_depart_id =", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdNotEqualTo(Long value) {
            addCriterion("send_depart_id <>", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdGreaterThan(Long value) {
            addCriterion("send_depart_id >", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdGreaterThanOrEqualTo(Long value) {
            addCriterion("send_depart_id >=", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdLessThan(Long value) {
            addCriterion("send_depart_id <", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdLessThanOrEqualTo(Long value) {
            addCriterion("send_depart_id <=", value, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdIn(List<Long> values) {
            addCriterion("send_depart_id in", values, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdNotIn(List<Long> values) {
            addCriterion("send_depart_id not in", values, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdBetween(Long value1, Long value2) {
            addCriterion("send_depart_id between", value1, value2, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartIdNotBetween(Long value1, Long value2) {
            addCriterion("send_depart_id not between", value1, value2, "sendDepartId");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameIsNull() {
            addCriterion("send_depart_name is null");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameIsNotNull() {
            addCriterion("send_depart_name is not null");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameEqualTo(String value) {
            addCriterion("send_depart_name =", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameNotEqualTo(String value) {
            addCriterion("send_depart_name <>", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameGreaterThan(String value) {
            addCriterion("send_depart_name >", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameGreaterThanOrEqualTo(String value) {
            addCriterion("send_depart_name >=", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameLessThan(String value) {
            addCriterion("send_depart_name <", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameLessThanOrEqualTo(String value) {
            addCriterion("send_depart_name <=", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameLike(String value) {
            addCriterion("send_depart_name like", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameNotLike(String value) {
            addCriterion("send_depart_name not like", value, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameIn(List<String> values) {
            addCriterion("send_depart_name in", values, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameNotIn(List<String> values) {
            addCriterion("send_depart_name not in", values, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameBetween(String value1, String value2) {
            addCriterion("send_depart_name between", value1, value2, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendDepartNameNotBetween(String value1, String value2) {
            addCriterion("send_depart_name not between", value1, value2, "sendDepartName");
            return (Criteria) this;
        }

        public Criteria andSendUserIdIsNull() {
            addCriterion("send_user_id is null");
            return (Criteria) this;
        }

        public Criteria andSendUserIdIsNotNull() {
            addCriterion("send_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andSendUserIdEqualTo(Long value) {
            addCriterion("send_user_id =", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdNotEqualTo(Long value) {
            addCriterion("send_user_id <>", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdGreaterThan(Long value) {
            addCriterion("send_user_id >", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("send_user_id >=", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdLessThan(Long value) {
            addCriterion("send_user_id <", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdLessThanOrEqualTo(Long value) {
            addCriterion("send_user_id <=", value, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdIn(List<Long> values) {
            addCriterion("send_user_id in", values, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdNotIn(List<Long> values) {
            addCriterion("send_user_id not in", values, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdBetween(Long value1, Long value2) {
            addCriterion("send_user_id between", value1, value2, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserIdNotBetween(Long value1, Long value2) {
            addCriterion("send_user_id not between", value1, value2, "sendUserId");
            return (Criteria) this;
        }

        public Criteria andSendUserNameIsNull() {
            addCriterion("send_user_name is null");
            return (Criteria) this;
        }

        public Criteria andSendUserNameIsNotNull() {
            addCriterion("send_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andSendUserNameEqualTo(String value) {
            addCriterion("send_user_name =", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameNotEqualTo(String value) {
            addCriterion("send_user_name <>", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameGreaterThan(String value) {
            addCriterion("send_user_name >", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("send_user_name >=", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameLessThan(String value) {
            addCriterion("send_user_name <", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameLessThanOrEqualTo(String value) {
            addCriterion("send_user_name <=", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameLike(String value) {
            addCriterion("send_user_name like", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameNotLike(String value) {
            addCriterion("send_user_name not like", value, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameIn(List<String> values) {
            addCriterion("send_user_name in", values, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameNotIn(List<String> values) {
            addCriterion("send_user_name not in", values, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameBetween(String value1, String value2) {
            addCriterion("send_user_name between", value1, value2, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendUserNameNotBetween(String value1, String value2) {
            addCriterion("send_user_name not between", value1, value2, "sendUserName");
            return (Criteria) this;
        }

        public Criteria andSendDateIsNull() {
            addCriterion("send_date is null");
            return (Criteria) this;
        }

        public Criteria andSendDateIsNotNull() {
            addCriterion("send_date is not null");
            return (Criteria) this;
        }

        public Criteria andSendDateEqualTo(Date value) {
            addCriterion("send_date =", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateNotEqualTo(Date value) {
            addCriterion("send_date <>", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateGreaterThan(Date value) {
            addCriterion("send_date >", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateGreaterThanOrEqualTo(Date value) {
            addCriterion("send_date >=", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateLessThan(Date value) {
            addCriterion("send_date <", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateLessThanOrEqualTo(Date value) {
            addCriterion("send_date <=", value, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateIn(List<Date> values) {
            addCriterion("send_date in", values, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateNotIn(List<Date> values) {
            addCriterion("send_date not in", values, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateBetween(Date value1, Date value2) {
            addCriterion("send_date between", value1, value2, "sendDate");
            return (Criteria) this;
        }

        public Criteria andSendDateNotBetween(Date value1, Date value2) {
            addCriterion("send_date not between", value1, value2, "sendDate");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdIsNull() {
            addCriterion("handle_company_id is null");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdIsNotNull() {
            addCriterion("handle_company_id is not null");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdEqualTo(Long value) {
            addCriterion("handle_company_id =", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdNotEqualTo(Long value) {
            addCriterion("handle_company_id <>", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdGreaterThan(Long value) {
            addCriterion("handle_company_id >", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdGreaterThanOrEqualTo(Long value) {
            addCriterion("handle_company_id >=", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdLessThan(Long value) {
            addCriterion("handle_company_id <", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdLessThanOrEqualTo(Long value) {
            addCriterion("handle_company_id <=", value, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdIn(List<Long> values) {
            addCriterion("handle_company_id in", values, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdNotIn(List<Long> values) {
            addCriterion("handle_company_id not in", values, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdBetween(Long value1, Long value2) {
            addCriterion("handle_company_id between", value1, value2, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyIdNotBetween(Long value1, Long value2) {
            addCriterion("handle_company_id not between", value1, value2, "handleCompanyId");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameIsNull() {
            addCriterion("handle_company_name is null");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameIsNotNull() {
            addCriterion("handle_company_name is not null");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameEqualTo(String value) {
            addCriterion("handle_company_name =", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameNotEqualTo(String value) {
            addCriterion("handle_company_name <>", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameGreaterThan(String value) {
            addCriterion("handle_company_name >", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameGreaterThanOrEqualTo(String value) {
            addCriterion("handle_company_name >=", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameLessThan(String value) {
            addCriterion("handle_company_name <", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameLessThanOrEqualTo(String value) {
            addCriterion("handle_company_name <=", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameLike(String value) {
            addCriterion("handle_company_name like", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameNotLike(String value) {
            addCriterion("handle_company_name not like", value, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameIn(List<String> values) {
            addCriterion("handle_company_name in", values, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameNotIn(List<String> values) {
            addCriterion("handle_company_name not in", values, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameBetween(String value1, String value2) {
            addCriterion("handle_company_name between", value1, value2, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleCompanyNameNotBetween(String value1, String value2) {
            addCriterion("handle_company_name not between", value1, value2, "handleCompanyName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdIsNull() {
            addCriterion("handle_depart_id is null");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdIsNotNull() {
            addCriterion("handle_depart_id is not null");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdEqualTo(Long value) {
            addCriterion("handle_depart_id =", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdNotEqualTo(Long value) {
            addCriterion("handle_depart_id <>", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdGreaterThan(Long value) {
            addCriterion("handle_depart_id >", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdGreaterThanOrEqualTo(Long value) {
            addCriterion("handle_depart_id >=", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdLessThan(Long value) {
            addCriterion("handle_depart_id <", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdLessThanOrEqualTo(Long value) {
            addCriterion("handle_depart_id <=", value, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdIn(List<Long> values) {
            addCriterion("handle_depart_id in", values, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdNotIn(List<Long> values) {
            addCriterion("handle_depart_id not in", values, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdBetween(Long value1, Long value2) {
            addCriterion("handle_depart_id between", value1, value2, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartIdNotBetween(Long value1, Long value2) {
            addCriterion("handle_depart_id not between", value1, value2, "handleDepartId");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameIsNull() {
            addCriterion("handle_depart_name is null");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameIsNotNull() {
            addCriterion("handle_depart_name is not null");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameEqualTo(String value) {
            addCriterion("handle_depart_name =", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameNotEqualTo(String value) {
            addCriterion("handle_depart_name <>", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameGreaterThan(String value) {
            addCriterion("handle_depart_name >", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameGreaterThanOrEqualTo(String value) {
            addCriterion("handle_depart_name >=", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameLessThan(String value) {
            addCriterion("handle_depart_name <", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameLessThanOrEqualTo(String value) {
            addCriterion("handle_depart_name <=", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameLike(String value) {
            addCriterion("handle_depart_name like", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameNotLike(String value) {
            addCriterion("handle_depart_name not like", value, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameIn(List<String> values) {
            addCriterion("handle_depart_name in", values, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameNotIn(List<String> values) {
            addCriterion("handle_depart_name not in", values, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameBetween(String value1, String value2) {
            addCriterion("handle_depart_name between", value1, value2, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleDepartNameNotBetween(String value1, String value2) {
            addCriterion("handle_depart_name not between", value1, value2, "handleDepartName");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdIsNull() {
            addCriterion("handle_user_id is null");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdIsNotNull() {
            addCriterion("handle_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdEqualTo(Long value) {
            addCriterion("handle_user_id =", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdNotEqualTo(Long value) {
            addCriterion("handle_user_id <>", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdGreaterThan(Long value) {
            addCriterion("handle_user_id >", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("handle_user_id >=", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdLessThan(Long value) {
            addCriterion("handle_user_id <", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdLessThanOrEqualTo(Long value) {
            addCriterion("handle_user_id <=", value, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdIn(List<Long> values) {
            addCriterion("handle_user_id in", values, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdNotIn(List<Long> values) {
            addCriterion("handle_user_id not in", values, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdBetween(Long value1, Long value2) {
            addCriterion("handle_user_id between", value1, value2, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserIdNotBetween(Long value1, Long value2) {
            addCriterion("handle_user_id not between", value1, value2, "handleUserId");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameIsNull() {
            addCriterion("handle_user_name is null");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameIsNotNull() {
            addCriterion("handle_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameEqualTo(String value) {
            addCriterion("handle_user_name =", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameNotEqualTo(String value) {
            addCriterion("handle_user_name <>", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameGreaterThan(String value) {
            addCriterion("handle_user_name >", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("handle_user_name >=", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameLessThan(String value) {
            addCriterion("handle_user_name <", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameLessThanOrEqualTo(String value) {
            addCriterion("handle_user_name <=", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameLike(String value) {
            addCriterion("handle_user_name like", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameNotLike(String value) {
            addCriterion("handle_user_name not like", value, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameIn(List<String> values) {
            addCriterion("handle_user_name in", values, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameNotIn(List<String> values) {
            addCriterion("handle_user_name not in", values, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameBetween(String value1, String value2) {
            addCriterion("handle_user_name between", value1, value2, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleUserNameNotBetween(String value1, String value2) {
            addCriterion("handle_user_name not between", value1, value2, "handleUserName");
            return (Criteria) this;
        }

        public Criteria andHandleStatusIsNull() {
            addCriterion("handle_status is null");
            return (Criteria) this;
        }

        public Criteria andHandleStatusIsNotNull() {
            addCriterion("handle_status is not null");
            return (Criteria) this;
        }

        public Criteria andHandleStatusEqualTo(Byte value) {
            addCriterion("handle_status =", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusNotEqualTo(Byte value) {
            addCriterion("handle_status <>", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusGreaterThan(Byte value) {
            addCriterion("handle_status >", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("handle_status >=", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusLessThan(Byte value) {
            addCriterion("handle_status <", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusLessThanOrEqualTo(Byte value) {
            addCriterion("handle_status <=", value, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusIn(List<Byte> values) {
            addCriterion("handle_status in", values, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusNotIn(List<Byte> values) {
            addCriterion("handle_status not in", values, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusBetween(Byte value1, Byte value2) {
            addCriterion("handle_status between", value1, value2, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andHandleStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("handle_status not between", value1, value2, "handleStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusIsNull() {
            addCriterion("timeout_status is null");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusIsNotNull() {
            addCriterion("timeout_status is not null");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusEqualTo(Byte value) {
            addCriterion("timeout_status =", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusNotEqualTo(Byte value) {
            addCriterion("timeout_status <>", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusGreaterThan(Byte value) {
            addCriterion("timeout_status >", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("timeout_status >=", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusLessThan(Byte value) {
            addCriterion("timeout_status <", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusLessThanOrEqualTo(Byte value) {
            addCriterion("timeout_status <=", value, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusIn(List<Byte> values) {
            addCriterion("timeout_status in", values, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusNotIn(List<Byte> values) {
            addCriterion("timeout_status not in", values, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusBetween(Byte value1, Byte value2) {
            addCriterion("timeout_status between", value1, value2, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andTimeoutStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("timeout_status not between", value1, value2, "timeoutStatus");
            return (Criteria) this;
        }

        public Criteria andReceiveDateIsNull() {
            addCriterion("receive_date is null");
            return (Criteria) this;
        }

        public Criteria andReceiveDateIsNotNull() {
            addCriterion("receive_date is not null");
            return (Criteria) this;
        }

        public Criteria andReceiveDateEqualTo(Date value) {
            addCriterion("receive_date =", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateNotEqualTo(Date value) {
            addCriterion("receive_date <>", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateGreaterThan(Date value) {
            addCriterion("receive_date >", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateGreaterThanOrEqualTo(Date value) {
            addCriterion("receive_date >=", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateLessThan(Date value) {
            addCriterion("receive_date <", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateLessThanOrEqualTo(Date value) {
            addCriterion("receive_date <=", value, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateIn(List<Date> values) {
            addCriterion("receive_date in", values, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateNotIn(List<Date> values) {
            addCriterion("receive_date not in", values, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateBetween(Date value1, Date value2) {
            addCriterion("receive_date between", value1, value2, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andReceiveDateNotBetween(Date value1, Date value2) {
            addCriterion("receive_date not between", value1, value2, "receiveDate");
            return (Criteria) this;
        }

        public Criteria andFinishTimeIsNull() {
            addCriterion("finish_time is null");
            return (Criteria) this;
        }

        public Criteria andFinishTimeIsNotNull() {
            addCriterion("finish_time is not null");
            return (Criteria) this;
        }

        public Criteria andFinishTimeEqualTo(String value) {
            addCriterion("finish_time =", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeNotEqualTo(String value) {
            addCriterion("finish_time <>", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeGreaterThan(String value) {
            addCriterion("finish_time >", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeGreaterThanOrEqualTo(String value) {
            addCriterion("finish_time >=", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeLessThan(String value) {
            addCriterion("finish_time <", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeLessThanOrEqualTo(String value) {
            addCriterion("finish_time <=", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeLike(String value) {
            addCriterion("finish_time like", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeNotLike(String value) {
            addCriterion("finish_time not like", value, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeIn(List<String> values) {
            addCriterion("finish_time in", values, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeNotIn(List<String> values) {
            addCriterion("finish_time not in", values, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeBetween(String value1, String value2) {
            addCriterion("finish_time between", value1, value2, "finishTime");
            return (Criteria) this;
        }

        public Criteria andFinishTimeNotBetween(String value1, String value2) {
            addCriterion("finish_time not between", value1, value2, "finishTime");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIsNull() {
            addCriterion("gmt_create is null");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIsNotNull() {
            addCriterion("gmt_create is not null");
            return (Criteria) this;
        }

        public Criteria andGmtCreateEqualTo(Date value) {
            addCriterion("gmt_create =", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotEqualTo(Date value) {
            addCriterion("gmt_create <>", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateGreaterThan(Date value) {
            addCriterion("gmt_create >", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateGreaterThanOrEqualTo(Date value) {
            addCriterion("gmt_create >=", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateLessThan(Date value) {
            addCriterion("gmt_create <", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateLessThanOrEqualTo(Date value) {
            addCriterion("gmt_create <=", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIn(List<Date> values) {
            addCriterion("gmt_create in", values, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotIn(List<Date> values) {
            addCriterion("gmt_create not in", values, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateBetween(Date value1, Date value2) {
            addCriterion("gmt_create between", value1, value2, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotBetween(Date value1, Date value2) {
            addCriterion("gmt_create not between", value1, value2, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIsNull() {
            addCriterion("gmt_modified is null");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIsNotNull() {
            addCriterion("gmt_modified is not null");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedEqualTo(Date value) {
            addCriterion("gmt_modified =", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotEqualTo(Date value) {
            addCriterion("gmt_modified <>", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedGreaterThan(Date value) {
            addCriterion("gmt_modified >", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedGreaterThanOrEqualTo(Date value) {
            addCriterion("gmt_modified >=", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedLessThan(Date value) {
            addCriterion("gmt_modified <", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedLessThanOrEqualTo(Date value) {
            addCriterion("gmt_modified <=", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIn(List<Date> values) {
            addCriterion("gmt_modified in", values, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotIn(List<Date> values) {
            addCriterion("gmt_modified not in", values, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedBetween(Date value1, Date value2) {
            addCriterion("gmt_modified between", value1, value2, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotBetween(Date value1, Date value2) {
            addCriterion("gmt_modified not between", value1, value2, "gmtModified");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}