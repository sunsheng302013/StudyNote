package com.differ.jackyun.oa.model;

import java.util.Date;

public class JOaFlowTodo {
    /** 主键ID自增*/
    private Integer id;

    /** 流程ID*/
    private Long flowId;

    /** 表单ID*/
    private Long formId;

    /** 工作流taskId*/
    private String taskId;

    /** 流程标题*/
    private String flowTitle;

    /** 优先级 默认0 普通0  紧急1*/
    private Byte priority;

    /** 流程状态 默认0 待办0  抄送1  完成2*/
    private Byte status;

    /** 流程状态 默认0*/
    private Byte flowStatus;

    /** 步骤序号*/
    private Integer stepOrder;

    /** 当前节点名称*/
    private String thisNodeName;

    /** 发起公司ID*/
    private Long startCompanyId;

    /** 发起公司名称*/
    private String startCompanyName;

    /** 发起部门ID*/
    private Long startDepartId;

    /** 发起部门名称*/
    private String startDepartName;

    /** 发起人ID*/
    private Long startUserId;

    /** 发起人姓名*/
    private String startUserName;

    /** 发起日期*/
    private Date startDate;

    /** 发送节点名称*/
    private String sendNodeName;

    /** 发送方式 默认0 提交1*/
    private Byte sendType;

    /** 发送部门ID*/
    private Long sendDepartId;

    /** 发送部门名称*/
    private String sendDepartName;

    /** 发送人ID*/
    private Long sendUserId;

    /** 发送人姓名*/
    private String sendUserName;

    /** 发送日期*/
    private Date sendDate;

    /** 处理公司ID*/
    private Long handleCompanyId;

    /** 处理公司名称*/
    private String handleCompanyName;

    /** 处理部门ID*/
    private Long handleDepartId;

    /** 处理部门名称*/
    private String handleDepartName;

    /** 处理人ID*/
    private Long handleUserId;

    /** 处理人姓名*/
    private String handleUserName;

    /** 执行状态 默认0 未阅读0、已阅读1、办理中2*/
    private Byte handleStatus;

    /** 耗时状态 默认0 未超时0、已超时1*/
    private Byte timeoutStatus;

    /** 送达日期*/
    private Date receiveDate;

    /** 时长 （办理结束时间—送达时间或者 办理结束时间—阅读时间；）*/
    private String finishTime;

    /** */
    private Date gmtCreate;

    /** */
    private Date gmtModified;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getFlowId() {
        return flowId;
    }

    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    public Long getFormId() {
        return formId;
    }

    public void setFormId(Long formId) {
        this.formId = formId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId == null ? null : taskId.trim();
    }

    public String getFlowTitle() {
        return flowTitle;
    }

    public void setFlowTitle(String flowTitle) {
        this.flowTitle = flowTitle == null ? null : flowTitle.trim();
    }

    public Byte getPriority() {
        return priority;
    }

    public void setPriority(Byte priority) {
        this.priority = priority;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Byte getFlowStatus() {
        return flowStatus;
    }

    public void setFlowStatus(Byte flowStatus) {
        this.flowStatus = flowStatus;
    }

    public Integer getStepOrder() {
        return stepOrder;
    }

    public void setStepOrder(Integer stepOrder) {
        this.stepOrder = stepOrder;
    }

    public String getThisNodeName() {
        return thisNodeName;
    }

    public void setThisNodeName(String thisNodeName) {
        this.thisNodeName = thisNodeName == null ? null : thisNodeName.trim();
    }

    public Long getStartCompanyId() {
        return startCompanyId;
    }

    public void setStartCompanyId(Long startCompanyId) {
        this.startCompanyId = startCompanyId;
    }

    public String getStartCompanyName() {
        return startCompanyName;
    }

    public void setStartCompanyName(String startCompanyName) {
        this.startCompanyName = startCompanyName == null ? null : startCompanyName.trim();
    }

    public Long getStartDepartId() {
        return startDepartId;
    }

    public void setStartDepartId(Long startDepartId) {
        this.startDepartId = startDepartId;
    }

    public String getStartDepartName() {
        return startDepartName;
    }

    public void setStartDepartName(String startDepartName) {
        this.startDepartName = startDepartName == null ? null : startDepartName.trim();
    }

    public Long getStartUserId() {
        return startUserId;
    }

    public void setStartUserId(Long startUserId) {
        this.startUserId = startUserId;
    }

    public String getStartUserName() {
        return startUserName;
    }

    public void setStartUserName(String startUserName) {
        this.startUserName = startUserName == null ? null : startUserName.trim();
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getSendNodeName() {
        return sendNodeName;
    }

    public void setSendNodeName(String sendNodeName) {
        this.sendNodeName = sendNodeName == null ? null : sendNodeName.trim();
    }

    public Byte getSendType() {
        return sendType;
    }

    public void setSendType(Byte sendType) {
        this.sendType = sendType;
    }

    public Long getSendDepartId() {
        return sendDepartId;
    }

    public void setSendDepartId(Long sendDepartId) {
        this.sendDepartId = sendDepartId;
    }

    public String getSendDepartName() {
        return sendDepartName;
    }

    public void setSendDepartName(String sendDepartName) {
        this.sendDepartName = sendDepartName == null ? null : sendDepartName.trim();
    }

    public Long getSendUserId() {
        return sendUserId;
    }

    public void setSendUserId(Long sendUserId) {
        this.sendUserId = sendUserId;
    }

    public String getSendUserName() {
        return sendUserName;
    }

    public void setSendUserName(String sendUserName) {
        this.sendUserName = sendUserName == null ? null : sendUserName.trim();
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }

    public Long getHandleCompanyId() {
        return handleCompanyId;
    }

    public void setHandleCompanyId(Long handleCompanyId) {
        this.handleCompanyId = handleCompanyId;
    }

    public String getHandleCompanyName() {
        return handleCompanyName;
    }

    public void setHandleCompanyName(String handleCompanyName) {
        this.handleCompanyName = handleCompanyName == null ? null : handleCompanyName.trim();
    }

    public Long getHandleDepartId() {
        return handleDepartId;
    }

    public void setHandleDepartId(Long handleDepartId) {
        this.handleDepartId = handleDepartId;
    }

    public String getHandleDepartName() {
        return handleDepartName;
    }

    public void setHandleDepartName(String handleDepartName) {
        this.handleDepartName = handleDepartName == null ? null : handleDepartName.trim();
    }

    public Long getHandleUserId() {
        return handleUserId;
    }

    public void setHandleUserId(Long handleUserId) {
        this.handleUserId = handleUserId;
    }

    public String getHandleUserName() {
        return handleUserName;
    }

    public void setHandleUserName(String handleUserName) {
        this.handleUserName = handleUserName == null ? null : handleUserName.trim();
    }

    public Byte getHandleStatus() {
        return handleStatus;
    }

    public void setHandleStatus(Byte handleStatus) {
        this.handleStatus = handleStatus;
    }

    public Byte getTimeoutStatus() {
        return timeoutStatus;
    }

    public void setTimeoutStatus(Byte timeoutStatus) {
        this.timeoutStatus = timeoutStatus;
    }

    public Date getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(Date receiveDate) {
        this.receiveDate = receiveDate;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime == null ? null : finishTime.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}