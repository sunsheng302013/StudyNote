package com.taotao.pojo;

public class GCfgWarehouselist {
    private Integer warehouseid;

    private String warehousename;

    private Integer orderpos;

    private Boolean bblockup;

    private Integer warehousetype;

    private String interfacetype;

    private String country;

    private String province;

    private String city;

    private String town;

    private String adr;

    private String tel;

    private String linkman;

    private String zip;

    private Byte bnegativestock;

    private Byte bautoaddgoods;

    public Integer getWarehouseid() {
        return warehouseid;
    }

    public void setWarehouseid(Integer warehouseid) {
        this.warehouseid = warehouseid;
    }

    public String getWarehousename() {
        return warehousename;
    }

    public void setWarehousename(String warehousename) {
        this.warehousename = warehousename == null ? null : warehousename.trim();
    }

    public Integer getOrderpos() {
        return orderpos;
    }

    public void setOrderpos(Integer orderpos) {
        this.orderpos = orderpos;
    }

    public Boolean getBblockup() {
        return bblockup;
    }

    public void setBblockup(Boolean bblockup) {
        this.bblockup = bblockup;
    }

    public Integer getWarehousetype() {
        return warehousetype;
    }

    public void setWarehousetype(Integer warehousetype) {
        this.warehousetype = warehousetype;
    }

    public String getInterfacetype() {
        return interfacetype;
    }

    public void setInterfacetype(String interfacetype) {
        this.interfacetype = interfacetype == null ? null : interfacetype.trim();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country == null ? null : country.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town == null ? null : town.trim();
    }

    public String getAdr() {
        return adr;
    }

    public void setAdr(String adr) {
        this.adr = adr == null ? null : adr.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman == null ? null : linkman.trim();
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip == null ? null : zip.trim();
    }

    public Byte getBnegativestock() {
        return bnegativestock;
    }

    public void setBnegativestock(Byte bnegativestock) {
        this.bnegativestock = bnegativestock;
    }

    public Byte getBautoaddgoods() {
        return bautoaddgoods;
    }

    public void setBautoaddgoods(Byte bautoaddgoods) {
        this.bautoaddgoods = bautoaddgoods;
    }
}