package com.taotao.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class GCfgShoplist {
    private Integer shopid;

    private String shopname;

    private String shoptype;

    private String website;

    private String linkman;

    private String adr;

    private String zip;

    private String tel;

    private String email;

    private String qq;

    private String remark;

    private Boolean bsndadr;

    private String country;

    private String province;

    private String city;

    private String town;

    private String billstyle;

    private String costrate;

    private Integer orderpos;

    private Boolean bblockup;

    private String loginuser;

    private String loginpwd;

    private String appkey;

    private String appsecret;

    private Boolean bsubaccount;

    private String chargetype;

    private Integer accountid;

    private String uid;

    private Integer warehouseid;

    private Integer containfx;

    private String key3;

    private String key4;

    private Boolean setapi;

    private String sellnick;

    private Boolean bsysstock;

    private Boolean bsysstockfx;

    private BigDecimal updateage;

    private Integer sysware;

    private Byte bchkstatus;

    private Boolean bchkbuyerremark;

    private String sessionkey;

    private Date sessiondate;

    private Date expiredate;

    private Date tbinctime;

    private Boolean bincget;

    private String syswarehouse;

    private Integer syspercentage;

    private Date autogettime;

    private String userid;

    private String userip;

    private Integer customerid;

    private Boolean ddprint;

    private Boolean brdspull;

    private Date rdstime;

    private Integer autogetdiv;

    private Boolean bautoget;

    private Boolean bgetrefuse;

    private Boolean bgetrefuseorder;

    private Date refuseinctime;

    private String jdcustcode;

    private Boolean bccc;

    private Integer rdschannel;

    private String setext;

    private Boolean bwlbcheck;

    private String paypaltoken;

    private String paypaluser;

    private String paypalpass;

    private String frontname;

    private String macadr;

    private String siteid;

    private String currencytype;

    private Byte bpostdelay;

    private Integer postdelaytime;

    private Byte bwaitunpay;

    private BigDecimal waitunpaytime;

    private Byte bgrm;

    private String grmcontent;

    private String ordertimepoint;

    public Integer getShopid() {
        return shopid;
    }

    public void setShopid(Integer shopid) {
        this.shopid = shopid;
    }

    public String getShopname() {
        return shopname;
    }

    public void setShopname(String shopname) {
        this.shopname = shopname == null ? null : shopname.trim();
    }

    public String getShoptype() {
        return shoptype;
    }

    public void setShoptype(String shoptype) {
        this.shoptype = shoptype == null ? null : shoptype.trim();
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website == null ? null : website.trim();
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman == null ? null : linkman.trim();
    }

    public String getAdr() {
        return adr;
    }

    public void setAdr(String adr) {
        this.adr = adr == null ? null : adr.trim();
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip == null ? null : zip.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq == null ? null : qq.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Boolean getBsndadr() {
        return bsndadr;
    }

    public void setBsndadr(Boolean bsndadr) {
        this.bsndadr = bsndadr;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country == null ? null : country.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town == null ? null : town.trim();
    }

    public String getBillstyle() {
        return billstyle;
    }

    public void setBillstyle(String billstyle) {
        this.billstyle = billstyle == null ? null : billstyle.trim();
    }

    public String getCostrate() {
        return costrate;
    }

    public void setCostrate(String costrate) {
        this.costrate = costrate == null ? null : costrate.trim();
    }

    public Integer getOrderpos() {
        return orderpos;
    }

    public void setOrderpos(Integer orderpos) {
        this.orderpos = orderpos;
    }

    public Boolean getBblockup() {
        return bblockup;
    }

    public void setBblockup(Boolean bblockup) {
        this.bblockup = bblockup;
    }

    public String getLoginuser() {
        return loginuser;
    }

    public void setLoginuser(String loginuser) {
        this.loginuser = loginuser == null ? null : loginuser.trim();
    }

    public String getLoginpwd() {
        return loginpwd;
    }

    public void setLoginpwd(String loginpwd) {
        this.loginpwd = loginpwd == null ? null : loginpwd.trim();
    }

    public String getAppkey() {
        return appkey;
    }

    public void setAppkey(String appkey) {
        this.appkey = appkey == null ? null : appkey.trim();
    }

    public String getAppsecret() {
        return appsecret;
    }

    public void setAppsecret(String appsecret) {
        this.appsecret = appsecret == null ? null : appsecret.trim();
    }

    public Boolean getBsubaccount() {
        return bsubaccount;
    }

    public void setBsubaccount(Boolean bsubaccount) {
        this.bsubaccount = bsubaccount;
    }

    public String getChargetype() {
        return chargetype;
    }

    public void setChargetype(String chargetype) {
        this.chargetype = chargetype == null ? null : chargetype.trim();
    }

    public Integer getAccountid() {
        return accountid;
    }

    public void setAccountid(Integer accountid) {
        this.accountid = accountid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid == null ? null : uid.trim();
    }

    public Integer getWarehouseid() {
        return warehouseid;
    }

    public void setWarehouseid(Integer warehouseid) {
        this.warehouseid = warehouseid;
    }

    public Integer getContainfx() {
        return containfx;
    }

    public void setContainfx(Integer containfx) {
        this.containfx = containfx;
    }

    public String getKey3() {
        return key3;
    }

    public void setKey3(String key3) {
        this.key3 = key3 == null ? null : key3.trim();
    }

    public String getKey4() {
        return key4;
    }

    public void setKey4(String key4) {
        this.key4 = key4 == null ? null : key4.trim();
    }

    public Boolean getSetapi() {
        return setapi;
    }

    public void setSetapi(Boolean setapi) {
        this.setapi = setapi;
    }

    public String getSellnick() {
        return sellnick;
    }

    public void setSellnick(String sellnick) {
        this.sellnick = sellnick == null ? null : sellnick.trim();
    }

    public Boolean getBsysstock() {
        return bsysstock;
    }

    public void setBsysstock(Boolean bsysstock) {
        this.bsysstock = bsysstock;
    }

    public Boolean getBsysstockfx() {
        return bsysstockfx;
    }

    public void setBsysstockfx(Boolean bsysstockfx) {
        this.bsysstockfx = bsysstockfx;
    }

    public BigDecimal getUpdateage() {
        return updateage;
    }

    public void setUpdateage(BigDecimal updateage) {
        this.updateage = updateage;
    }

    public Integer getSysware() {
        return sysware;
    }

    public void setSysware(Integer sysware) {
        this.sysware = sysware;
    }

    public Byte getBchkstatus() {
        return bchkstatus;
    }

    public void setBchkstatus(Byte bchkstatus) {
        this.bchkstatus = bchkstatus;
    }

    public Boolean getBchkbuyerremark() {
        return bchkbuyerremark;
    }

    public void setBchkbuyerremark(Boolean bchkbuyerremark) {
        this.bchkbuyerremark = bchkbuyerremark;
    }

    public String getSessionkey() {
        return sessionkey;
    }

    public void setSessionkey(String sessionkey) {
        this.sessionkey = sessionkey == null ? null : sessionkey.trim();
    }

    public Date getSessiondate() {
        return sessiondate;
    }

    public void setSessiondate(Date sessiondate) {
        this.sessiondate = sessiondate;
    }

    public Date getExpiredate() {
        return expiredate;
    }

    public void setExpiredate(Date expiredate) {
        this.expiredate = expiredate;
    }

    public Date getTbinctime() {
        return tbinctime;
    }

    public void setTbinctime(Date tbinctime) {
        this.tbinctime = tbinctime;
    }

    public Boolean getBincget() {
        return bincget;
    }

    public void setBincget(Boolean bincget) {
        this.bincget = bincget;
    }

    public String getSyswarehouse() {
        return syswarehouse;
    }

    public void setSyswarehouse(String syswarehouse) {
        this.syswarehouse = syswarehouse == null ? null : syswarehouse.trim();
    }

    public Integer getSyspercentage() {
        return syspercentage;
    }

    public void setSyspercentage(Integer syspercentage) {
        this.syspercentage = syspercentage;
    }

    public Date getAutogettime() {
        return autogettime;
    }

    public void setAutogettime(Date autogettime) {
        this.autogettime = autogettime;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getUserip() {
        return userip;
    }

    public void setUserip(String userip) {
        this.userip = userip == null ? null : userip.trim();
    }

    public Integer getCustomerid() {
        return customerid;
    }

    public void setCustomerid(Integer customerid) {
        this.customerid = customerid;
    }

    public Boolean getDdprint() {
        return ddprint;
    }

    public void setDdprint(Boolean ddprint) {
        this.ddprint = ddprint;
    }

    public Boolean getBrdspull() {
        return brdspull;
    }

    public void setBrdspull(Boolean brdspull) {
        this.brdspull = brdspull;
    }

    public Date getRdstime() {
        return rdstime;
    }

    public void setRdstime(Date rdstime) {
        this.rdstime = rdstime;
    }

    public Integer getAutogetdiv() {
        return autogetdiv;
    }

    public void setAutogetdiv(Integer autogetdiv) {
        this.autogetdiv = autogetdiv;
    }

    public Boolean getBautoget() {
        return bautoget;
    }

    public void setBautoget(Boolean bautoget) {
        this.bautoget = bautoget;
    }

    public Boolean getBgetrefuse() {
        return bgetrefuse;
    }

    public void setBgetrefuse(Boolean bgetrefuse) {
        this.bgetrefuse = bgetrefuse;
    }

    public Boolean getBgetrefuseorder() {
        return bgetrefuseorder;
    }

    public void setBgetrefuseorder(Boolean bgetrefuseorder) {
        this.bgetrefuseorder = bgetrefuseorder;
    }

    public Date getRefuseinctime() {
        return refuseinctime;
    }

    public void setRefuseinctime(Date refuseinctime) {
        this.refuseinctime = refuseinctime;
    }

    public String getJdcustcode() {
        return jdcustcode;
    }

    public void setJdcustcode(String jdcustcode) {
        this.jdcustcode = jdcustcode == null ? null : jdcustcode.trim();
    }

    public Boolean getBccc() {
        return bccc;
    }

    public void setBccc(Boolean bccc) {
        this.bccc = bccc;
    }

    public Integer getRdschannel() {
        return rdschannel;
    }

    public void setRdschannel(Integer rdschannel) {
        this.rdschannel = rdschannel;
    }

    public String getSetext() {
        return setext;
    }

    public void setSetext(String setext) {
        this.setext = setext == null ? null : setext.trim();
    }

    public Boolean getBwlbcheck() {
        return bwlbcheck;
    }

    public void setBwlbcheck(Boolean bwlbcheck) {
        this.bwlbcheck = bwlbcheck;
    }

    public String getPaypaltoken() {
        return paypaltoken;
    }

    public void setPaypaltoken(String paypaltoken) {
        this.paypaltoken = paypaltoken == null ? null : paypaltoken.trim();
    }

    public String getPaypaluser() {
        return paypaluser;
    }

    public void setPaypaluser(String paypaluser) {
        this.paypaluser = paypaluser == null ? null : paypaluser.trim();
    }

    public String getPaypalpass() {
        return paypalpass;
    }

    public void setPaypalpass(String paypalpass) {
        this.paypalpass = paypalpass == null ? null : paypalpass.trim();
    }

    public String getFrontname() {
        return frontname;
    }

    public void setFrontname(String frontname) {
        this.frontname = frontname == null ? null : frontname.trim();
    }

    public String getMacadr() {
        return macadr;
    }

    public void setMacadr(String macadr) {
        this.macadr = macadr == null ? null : macadr.trim();
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid == null ? null : siteid.trim();
    }

    public String getCurrencytype() {
        return currencytype;
    }

    public void setCurrencytype(String currencytype) {
        this.currencytype = currencytype == null ? null : currencytype.trim();
    }

    public Byte getBpostdelay() {
        return bpostdelay;
    }

    public void setBpostdelay(Byte bpostdelay) {
        this.bpostdelay = bpostdelay;
    }

    public Integer getPostdelaytime() {
        return postdelaytime;
    }

    public void setPostdelaytime(Integer postdelaytime) {
        this.postdelaytime = postdelaytime;
    }

    public Byte getBwaitunpay() {
        return bwaitunpay;
    }

    public void setBwaitunpay(Byte bwaitunpay) {
        this.bwaitunpay = bwaitunpay;
    }

    public BigDecimal getWaitunpaytime() {
        return waitunpaytime;
    }

    public void setWaitunpaytime(BigDecimal waitunpaytime) {
        this.waitunpaytime = waitunpaytime;
    }

    public Byte getBgrm() {
        return bgrm;
    }

    public void setBgrm(Byte bgrm) {
        this.bgrm = bgrm;
    }

    public String getGrmcontent() {
        return grmcontent;
    }

    public void setGrmcontent(String grmcontent) {
        this.grmcontent = grmcontent == null ? null : grmcontent.trim();
    }

    public String getOrdertimepoint() {
        return ordertimepoint;
    }

    public void setOrdertimepoint(String ordertimepoint) {
        this.ordertimepoint = ordertimepoint == null ? null : ordertimepoint.trim();
    }
}