package com.taotao.mapper;

import com.taotao.pojo.GCfgSpeclist;
import com.taotao.pojo.GCfgSpeclistExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GCfgSpeclistMapper {
    int countByExample(GCfgSpeclistExample example);

    int deleteByExample(GCfgSpeclistExample example);

    int deleteByPrimaryKey(Integer recid);

    int insert(GCfgSpeclist record);

    int insertSelective(GCfgSpeclist record);

    List<GCfgSpeclist> selectByExample(GCfgSpeclistExample example);

    GCfgSpeclist selectByPrimaryKey(Integer recid);

    int updateByExampleSelective(@Param("record") GCfgSpeclist record, @Param("example") GCfgSpeclistExample example);

    int updateByExample(@Param("record") GCfgSpeclist record, @Param("example") GCfgSpeclistExample example);

    int updateByPrimaryKeySelective(GCfgSpeclist record);

    int updateByPrimaryKey(GCfgSpeclist record);
}