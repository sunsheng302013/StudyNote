package com.differ.jackyun.oa.dao;

import com.differ.jackyun.oa.model.JOaFlowTodo;
import com.differ.jackyun.oa.model.JOaFlowTodoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface JOaFlowTodoMapper {
    int countByExample(JOaFlowTodoExample example);

    int deleteByExample(JOaFlowTodoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(JOaFlowTodo record);

    int insertSelective(JOaFlowTodo record);

    List<JOaFlowTodo> selectByExample(JOaFlowTodoExample example);

    JOaFlowTodo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") JOaFlowTodo record, @Param("example") JOaFlowTodoExample example);

    int updateByExample(@Param("record") JOaFlowTodo record, @Param("example") JOaFlowTodoExample example);

    int updateByPrimaryKeySelective(JOaFlowTodo record);

    int updateByPrimaryKey(JOaFlowTodo record);
}