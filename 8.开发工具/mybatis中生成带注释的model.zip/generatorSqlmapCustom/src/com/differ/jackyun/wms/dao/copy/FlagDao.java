package com.differ.jackyun.wms.dao.copy;

public interface FlagDao {

}