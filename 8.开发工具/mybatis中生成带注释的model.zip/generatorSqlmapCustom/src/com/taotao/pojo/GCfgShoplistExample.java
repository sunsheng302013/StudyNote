package com.taotao.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GCfgShoplistExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public GCfgShoplistExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andShopidIsNull() {
            addCriterion("ShopID is null");
            return (Criteria) this;
        }

        public Criteria andShopidIsNotNull() {
            addCriterion("ShopID is not null");
            return (Criteria) this;
        }

        public Criteria andShopidEqualTo(Integer value) {
            addCriterion("ShopID =", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidNotEqualTo(Integer value) {
            addCriterion("ShopID <>", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidGreaterThan(Integer value) {
            addCriterion("ShopID >", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ShopID >=", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidLessThan(Integer value) {
            addCriterion("ShopID <", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidLessThanOrEqualTo(Integer value) {
            addCriterion("ShopID <=", value, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidIn(List<Integer> values) {
            addCriterion("ShopID in", values, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidNotIn(List<Integer> values) {
            addCriterion("ShopID not in", values, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidBetween(Integer value1, Integer value2) {
            addCriterion("ShopID between", value1, value2, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopidNotBetween(Integer value1, Integer value2) {
            addCriterion("ShopID not between", value1, value2, "shopid");
            return (Criteria) this;
        }

        public Criteria andShopnameIsNull() {
            addCriterion("ShopName is null");
            return (Criteria) this;
        }

        public Criteria andShopnameIsNotNull() {
            addCriterion("ShopName is not null");
            return (Criteria) this;
        }

        public Criteria andShopnameEqualTo(String value) {
            addCriterion("ShopName =", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameNotEqualTo(String value) {
            addCriterion("ShopName <>", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameGreaterThan(String value) {
            addCriterion("ShopName >", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameGreaterThanOrEqualTo(String value) {
            addCriterion("ShopName >=", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameLessThan(String value) {
            addCriterion("ShopName <", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameLessThanOrEqualTo(String value) {
            addCriterion("ShopName <=", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameLike(String value) {
            addCriterion("ShopName like", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameNotLike(String value) {
            addCriterion("ShopName not like", value, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameIn(List<String> values) {
            addCriterion("ShopName in", values, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameNotIn(List<String> values) {
            addCriterion("ShopName not in", values, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameBetween(String value1, String value2) {
            addCriterion("ShopName between", value1, value2, "shopname");
            return (Criteria) this;
        }

        public Criteria andShopnameNotBetween(String value1, String value2) {
            addCriterion("ShopName not between", value1, value2, "shopname");
            return (Criteria) this;
        }

        public Criteria andShoptypeIsNull() {
            addCriterion("ShopType is null");
            return (Criteria) this;
        }

        public Criteria andShoptypeIsNotNull() {
            addCriterion("ShopType is not null");
            return (Criteria) this;
        }

        public Criteria andShoptypeEqualTo(String value) {
            addCriterion("ShopType =", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeNotEqualTo(String value) {
            addCriterion("ShopType <>", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeGreaterThan(String value) {
            addCriterion("ShopType >", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeGreaterThanOrEqualTo(String value) {
            addCriterion("ShopType >=", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeLessThan(String value) {
            addCriterion("ShopType <", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeLessThanOrEqualTo(String value) {
            addCriterion("ShopType <=", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeLike(String value) {
            addCriterion("ShopType like", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeNotLike(String value) {
            addCriterion("ShopType not like", value, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeIn(List<String> values) {
            addCriterion("ShopType in", values, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeNotIn(List<String> values) {
            addCriterion("ShopType not in", values, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeBetween(String value1, String value2) {
            addCriterion("ShopType between", value1, value2, "shoptype");
            return (Criteria) this;
        }

        public Criteria andShoptypeNotBetween(String value1, String value2) {
            addCriterion("ShopType not between", value1, value2, "shoptype");
            return (Criteria) this;
        }

        public Criteria andWebsiteIsNull() {
            addCriterion("Website is null");
            return (Criteria) this;
        }

        public Criteria andWebsiteIsNotNull() {
            addCriterion("Website is not null");
            return (Criteria) this;
        }

        public Criteria andWebsiteEqualTo(String value) {
            addCriterion("Website =", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteNotEqualTo(String value) {
            addCriterion("Website <>", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteGreaterThan(String value) {
            addCriterion("Website >", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteGreaterThanOrEqualTo(String value) {
            addCriterion("Website >=", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteLessThan(String value) {
            addCriterion("Website <", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteLessThanOrEqualTo(String value) {
            addCriterion("Website <=", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteLike(String value) {
            addCriterion("Website like", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteNotLike(String value) {
            addCriterion("Website not like", value, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteIn(List<String> values) {
            addCriterion("Website in", values, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteNotIn(List<String> values) {
            addCriterion("Website not in", values, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteBetween(String value1, String value2) {
            addCriterion("Website between", value1, value2, "website");
            return (Criteria) this;
        }

        public Criteria andWebsiteNotBetween(String value1, String value2) {
            addCriterion("Website not between", value1, value2, "website");
            return (Criteria) this;
        }

        public Criteria andLinkmanIsNull() {
            addCriterion("Linkman is null");
            return (Criteria) this;
        }

        public Criteria andLinkmanIsNotNull() {
            addCriterion("Linkman is not null");
            return (Criteria) this;
        }

        public Criteria andLinkmanEqualTo(String value) {
            addCriterion("Linkman =", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotEqualTo(String value) {
            addCriterion("Linkman <>", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanGreaterThan(String value) {
            addCriterion("Linkman >", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanGreaterThanOrEqualTo(String value) {
            addCriterion("Linkman >=", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLessThan(String value) {
            addCriterion("Linkman <", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLessThanOrEqualTo(String value) {
            addCriterion("Linkman <=", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLike(String value) {
            addCriterion("Linkman like", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotLike(String value) {
            addCriterion("Linkman not like", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanIn(List<String> values) {
            addCriterion("Linkman in", values, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotIn(List<String> values) {
            addCriterion("Linkman not in", values, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanBetween(String value1, String value2) {
            addCriterion("Linkman between", value1, value2, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotBetween(String value1, String value2) {
            addCriterion("Linkman not between", value1, value2, "linkman");
            return (Criteria) this;
        }

        public Criteria andAdrIsNull() {
            addCriterion("Adr is null");
            return (Criteria) this;
        }

        public Criteria andAdrIsNotNull() {
            addCriterion("Adr is not null");
            return (Criteria) this;
        }

        public Criteria andAdrEqualTo(String value) {
            addCriterion("Adr =", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotEqualTo(String value) {
            addCriterion("Adr <>", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrGreaterThan(String value) {
            addCriterion("Adr >", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrGreaterThanOrEqualTo(String value) {
            addCriterion("Adr >=", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLessThan(String value) {
            addCriterion("Adr <", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLessThanOrEqualTo(String value) {
            addCriterion("Adr <=", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLike(String value) {
            addCriterion("Adr like", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotLike(String value) {
            addCriterion("Adr not like", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrIn(List<String> values) {
            addCriterion("Adr in", values, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotIn(List<String> values) {
            addCriterion("Adr not in", values, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrBetween(String value1, String value2) {
            addCriterion("Adr between", value1, value2, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotBetween(String value1, String value2) {
            addCriterion("Adr not between", value1, value2, "adr");
            return (Criteria) this;
        }

        public Criteria andZipIsNull() {
            addCriterion("Zip is null");
            return (Criteria) this;
        }

        public Criteria andZipIsNotNull() {
            addCriterion("Zip is not null");
            return (Criteria) this;
        }

        public Criteria andZipEqualTo(String value) {
            addCriterion("Zip =", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotEqualTo(String value) {
            addCriterion("Zip <>", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThan(String value) {
            addCriterion("Zip >", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThanOrEqualTo(String value) {
            addCriterion("Zip >=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThan(String value) {
            addCriterion("Zip <", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThanOrEqualTo(String value) {
            addCriterion("Zip <=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLike(String value) {
            addCriterion("Zip like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotLike(String value) {
            addCriterion("Zip not like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipIn(List<String> values) {
            addCriterion("Zip in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotIn(List<String> values) {
            addCriterion("Zip not in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipBetween(String value1, String value2) {
            addCriterion("Zip between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotBetween(String value1, String value2) {
            addCriterion("Zip not between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andTelIsNull() {
            addCriterion("Tel is null");
            return (Criteria) this;
        }

        public Criteria andTelIsNotNull() {
            addCriterion("Tel is not null");
            return (Criteria) this;
        }

        public Criteria andTelEqualTo(String value) {
            addCriterion("Tel =", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotEqualTo(String value) {
            addCriterion("Tel <>", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThan(String value) {
            addCriterion("Tel >", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThanOrEqualTo(String value) {
            addCriterion("Tel >=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThan(String value) {
            addCriterion("Tel <", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThanOrEqualTo(String value) {
            addCriterion("Tel <=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLike(String value) {
            addCriterion("Tel like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotLike(String value) {
            addCriterion("Tel not like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelIn(List<String> values) {
            addCriterion("Tel in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotIn(List<String> values) {
            addCriterion("Tel not in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelBetween(String value1, String value2) {
            addCriterion("Tel between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotBetween(String value1, String value2) {
            addCriterion("Tel not between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("Email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("Email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("Email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("Email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("Email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("Email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("Email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("Email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("Email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("Email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("Email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("Email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("Email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("Email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andQqIsNull() {
            addCriterion("QQ is null");
            return (Criteria) this;
        }

        public Criteria andQqIsNotNull() {
            addCriterion("QQ is not null");
            return (Criteria) this;
        }

        public Criteria andQqEqualTo(String value) {
            addCriterion("QQ =", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotEqualTo(String value) {
            addCriterion("QQ <>", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqGreaterThan(String value) {
            addCriterion("QQ >", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqGreaterThanOrEqualTo(String value) {
            addCriterion("QQ >=", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLessThan(String value) {
            addCriterion("QQ <", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLessThanOrEqualTo(String value) {
            addCriterion("QQ <=", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqLike(String value) {
            addCriterion("QQ like", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotLike(String value) {
            addCriterion("QQ not like", value, "qq");
            return (Criteria) this;
        }

        public Criteria andQqIn(List<String> values) {
            addCriterion("QQ in", values, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotIn(List<String> values) {
            addCriterion("QQ not in", values, "qq");
            return (Criteria) this;
        }

        public Criteria andQqBetween(String value1, String value2) {
            addCriterion("QQ between", value1, value2, "qq");
            return (Criteria) this;
        }

        public Criteria andQqNotBetween(String value1, String value2) {
            addCriterion("QQ not between", value1, value2, "qq");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("Remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("Remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("Remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("Remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("Remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("Remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("Remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("Remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("Remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("Remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("Remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("Remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("Remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("Remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andBsndadrIsNull() {
            addCriterion("bSndAdr is null");
            return (Criteria) this;
        }

        public Criteria andBsndadrIsNotNull() {
            addCriterion("bSndAdr is not null");
            return (Criteria) this;
        }

        public Criteria andBsndadrEqualTo(Boolean value) {
            addCriterion("bSndAdr =", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrNotEqualTo(Boolean value) {
            addCriterion("bSndAdr <>", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrGreaterThan(Boolean value) {
            addCriterion("bSndAdr >", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bSndAdr >=", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrLessThan(Boolean value) {
            addCriterion("bSndAdr <", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrLessThanOrEqualTo(Boolean value) {
            addCriterion("bSndAdr <=", value, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrIn(List<Boolean> values) {
            addCriterion("bSndAdr in", values, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrNotIn(List<Boolean> values) {
            addCriterion("bSndAdr not in", values, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrBetween(Boolean value1, Boolean value2) {
            addCriterion("bSndAdr between", value1, value2, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andBsndadrNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bSndAdr not between", value1, value2, "bsndadr");
            return (Criteria) this;
        }

        public Criteria andCountryIsNull() {
            addCriterion("Country is null");
            return (Criteria) this;
        }

        public Criteria andCountryIsNotNull() {
            addCriterion("Country is not null");
            return (Criteria) this;
        }

        public Criteria andCountryEqualTo(String value) {
            addCriterion("Country =", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotEqualTo(String value) {
            addCriterion("Country <>", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThan(String value) {
            addCriterion("Country >", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThanOrEqualTo(String value) {
            addCriterion("Country >=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThan(String value) {
            addCriterion("Country <", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThanOrEqualTo(String value) {
            addCriterion("Country <=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLike(String value) {
            addCriterion("Country like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotLike(String value) {
            addCriterion("Country not like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryIn(List<String> values) {
            addCriterion("Country in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotIn(List<String> values) {
            addCriterion("Country not in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryBetween(String value1, String value2) {
            addCriterion("Country between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotBetween(String value1, String value2) {
            addCriterion("Country not between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNull() {
            addCriterion("Province is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNotNull() {
            addCriterion("Province is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceEqualTo(String value) {
            addCriterion("Province =", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotEqualTo(String value) {
            addCriterion("Province <>", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThan(String value) {
            addCriterion("Province >", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThanOrEqualTo(String value) {
            addCriterion("Province >=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThan(String value) {
            addCriterion("Province <", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThanOrEqualTo(String value) {
            addCriterion("Province <=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLike(String value) {
            addCriterion("Province like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotLike(String value) {
            addCriterion("Province not like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceIn(List<String> values) {
            addCriterion("Province in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotIn(List<String> values) {
            addCriterion("Province not in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceBetween(String value1, String value2) {
            addCriterion("Province between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotBetween(String value1, String value2) {
            addCriterion("Province not between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("City is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("City is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("City =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("City <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("City >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("City >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("City <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("City <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("City like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("City not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("City in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("City not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("City between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("City not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andTownIsNull() {
            addCriterion("Town is null");
            return (Criteria) this;
        }

        public Criteria andTownIsNotNull() {
            addCriterion("Town is not null");
            return (Criteria) this;
        }

        public Criteria andTownEqualTo(String value) {
            addCriterion("Town =", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotEqualTo(String value) {
            addCriterion("Town <>", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownGreaterThan(String value) {
            addCriterion("Town >", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownGreaterThanOrEqualTo(String value) {
            addCriterion("Town >=", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLessThan(String value) {
            addCriterion("Town <", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLessThanOrEqualTo(String value) {
            addCriterion("Town <=", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLike(String value) {
            addCriterion("Town like", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotLike(String value) {
            addCriterion("Town not like", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownIn(List<String> values) {
            addCriterion("Town in", values, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotIn(List<String> values) {
            addCriterion("Town not in", values, "town");
            return (Criteria) this;
        }

        public Criteria andTownBetween(String value1, String value2) {
            addCriterion("Town between", value1, value2, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotBetween(String value1, String value2) {
            addCriterion("Town not between", value1, value2, "town");
            return (Criteria) this;
        }

        public Criteria andBillstyleIsNull() {
            addCriterion("BillStyle is null");
            return (Criteria) this;
        }

        public Criteria andBillstyleIsNotNull() {
            addCriterion("BillStyle is not null");
            return (Criteria) this;
        }

        public Criteria andBillstyleEqualTo(String value) {
            addCriterion("BillStyle =", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleNotEqualTo(String value) {
            addCriterion("BillStyle <>", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleGreaterThan(String value) {
            addCriterion("BillStyle >", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleGreaterThanOrEqualTo(String value) {
            addCriterion("BillStyle >=", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleLessThan(String value) {
            addCriterion("BillStyle <", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleLessThanOrEqualTo(String value) {
            addCriterion("BillStyle <=", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleLike(String value) {
            addCriterion("BillStyle like", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleNotLike(String value) {
            addCriterion("BillStyle not like", value, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleIn(List<String> values) {
            addCriterion("BillStyle in", values, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleNotIn(List<String> values) {
            addCriterion("BillStyle not in", values, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleBetween(String value1, String value2) {
            addCriterion("BillStyle between", value1, value2, "billstyle");
            return (Criteria) this;
        }

        public Criteria andBillstyleNotBetween(String value1, String value2) {
            addCriterion("BillStyle not between", value1, value2, "billstyle");
            return (Criteria) this;
        }

        public Criteria andCostrateIsNull() {
            addCriterion("CostRate is null");
            return (Criteria) this;
        }

        public Criteria andCostrateIsNotNull() {
            addCriterion("CostRate is not null");
            return (Criteria) this;
        }

        public Criteria andCostrateEqualTo(String value) {
            addCriterion("CostRate =", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateNotEqualTo(String value) {
            addCriterion("CostRate <>", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateGreaterThan(String value) {
            addCriterion("CostRate >", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateGreaterThanOrEqualTo(String value) {
            addCriterion("CostRate >=", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateLessThan(String value) {
            addCriterion("CostRate <", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateLessThanOrEqualTo(String value) {
            addCriterion("CostRate <=", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateLike(String value) {
            addCriterion("CostRate like", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateNotLike(String value) {
            addCriterion("CostRate not like", value, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateIn(List<String> values) {
            addCriterion("CostRate in", values, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateNotIn(List<String> values) {
            addCriterion("CostRate not in", values, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateBetween(String value1, String value2) {
            addCriterion("CostRate between", value1, value2, "costrate");
            return (Criteria) this;
        }

        public Criteria andCostrateNotBetween(String value1, String value2) {
            addCriterion("CostRate not between", value1, value2, "costrate");
            return (Criteria) this;
        }

        public Criteria andOrderposIsNull() {
            addCriterion("OrderPos is null");
            return (Criteria) this;
        }

        public Criteria andOrderposIsNotNull() {
            addCriterion("OrderPos is not null");
            return (Criteria) this;
        }

        public Criteria andOrderposEqualTo(Integer value) {
            addCriterion("OrderPos =", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotEqualTo(Integer value) {
            addCriterion("OrderPos <>", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposGreaterThan(Integer value) {
            addCriterion("OrderPos >", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposGreaterThanOrEqualTo(Integer value) {
            addCriterion("OrderPos >=", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposLessThan(Integer value) {
            addCriterion("OrderPos <", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposLessThanOrEqualTo(Integer value) {
            addCriterion("OrderPos <=", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposIn(List<Integer> values) {
            addCriterion("OrderPos in", values, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotIn(List<Integer> values) {
            addCriterion("OrderPos not in", values, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposBetween(Integer value1, Integer value2) {
            addCriterion("OrderPos between", value1, value2, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotBetween(Integer value1, Integer value2) {
            addCriterion("OrderPos not between", value1, value2, "orderpos");
            return (Criteria) this;
        }

        public Criteria andBblockupIsNull() {
            addCriterion("bBlockUp is null");
            return (Criteria) this;
        }

        public Criteria andBblockupIsNotNull() {
            addCriterion("bBlockUp is not null");
            return (Criteria) this;
        }

        public Criteria andBblockupEqualTo(Boolean value) {
            addCriterion("bBlockUp =", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotEqualTo(Boolean value) {
            addCriterion("bBlockUp <>", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupGreaterThan(Boolean value) {
            addCriterion("bBlockUp >", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bBlockUp >=", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupLessThan(Boolean value) {
            addCriterion("bBlockUp <", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupLessThanOrEqualTo(Boolean value) {
            addCriterion("bBlockUp <=", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupIn(List<Boolean> values) {
            addCriterion("bBlockUp in", values, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotIn(List<Boolean> values) {
            addCriterion("bBlockUp not in", values, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupBetween(Boolean value1, Boolean value2) {
            addCriterion("bBlockUp between", value1, value2, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bBlockUp not between", value1, value2, "bblockup");
            return (Criteria) this;
        }

        public Criteria andLoginuserIsNull() {
            addCriterion("LoginUser is null");
            return (Criteria) this;
        }

        public Criteria andLoginuserIsNotNull() {
            addCriterion("LoginUser is not null");
            return (Criteria) this;
        }

        public Criteria andLoginuserEqualTo(String value) {
            addCriterion("LoginUser =", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserNotEqualTo(String value) {
            addCriterion("LoginUser <>", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserGreaterThan(String value) {
            addCriterion("LoginUser >", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserGreaterThanOrEqualTo(String value) {
            addCriterion("LoginUser >=", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserLessThan(String value) {
            addCriterion("LoginUser <", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserLessThanOrEqualTo(String value) {
            addCriterion("LoginUser <=", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserLike(String value) {
            addCriterion("LoginUser like", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserNotLike(String value) {
            addCriterion("LoginUser not like", value, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserIn(List<String> values) {
            addCriterion("LoginUser in", values, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserNotIn(List<String> values) {
            addCriterion("LoginUser not in", values, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserBetween(String value1, String value2) {
            addCriterion("LoginUser between", value1, value2, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginuserNotBetween(String value1, String value2) {
            addCriterion("LoginUser not between", value1, value2, "loginuser");
            return (Criteria) this;
        }

        public Criteria andLoginpwdIsNull() {
            addCriterion("LoginPWD is null");
            return (Criteria) this;
        }

        public Criteria andLoginpwdIsNotNull() {
            addCriterion("LoginPWD is not null");
            return (Criteria) this;
        }

        public Criteria andLoginpwdEqualTo(String value) {
            addCriterion("LoginPWD =", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdNotEqualTo(String value) {
            addCriterion("LoginPWD <>", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdGreaterThan(String value) {
            addCriterion("LoginPWD >", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdGreaterThanOrEqualTo(String value) {
            addCriterion("LoginPWD >=", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdLessThan(String value) {
            addCriterion("LoginPWD <", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdLessThanOrEqualTo(String value) {
            addCriterion("LoginPWD <=", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdLike(String value) {
            addCriterion("LoginPWD like", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdNotLike(String value) {
            addCriterion("LoginPWD not like", value, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdIn(List<String> values) {
            addCriterion("LoginPWD in", values, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdNotIn(List<String> values) {
            addCriterion("LoginPWD not in", values, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdBetween(String value1, String value2) {
            addCriterion("LoginPWD between", value1, value2, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andLoginpwdNotBetween(String value1, String value2) {
            addCriterion("LoginPWD not between", value1, value2, "loginpwd");
            return (Criteria) this;
        }

        public Criteria andAppkeyIsNull() {
            addCriterion("AppKey is null");
            return (Criteria) this;
        }

        public Criteria andAppkeyIsNotNull() {
            addCriterion("AppKey is not null");
            return (Criteria) this;
        }

        public Criteria andAppkeyEqualTo(String value) {
            addCriterion("AppKey =", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyNotEqualTo(String value) {
            addCriterion("AppKey <>", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyGreaterThan(String value) {
            addCriterion("AppKey >", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyGreaterThanOrEqualTo(String value) {
            addCriterion("AppKey >=", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyLessThan(String value) {
            addCriterion("AppKey <", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyLessThanOrEqualTo(String value) {
            addCriterion("AppKey <=", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyLike(String value) {
            addCriterion("AppKey like", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyNotLike(String value) {
            addCriterion("AppKey not like", value, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyIn(List<String> values) {
            addCriterion("AppKey in", values, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyNotIn(List<String> values) {
            addCriterion("AppKey not in", values, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyBetween(String value1, String value2) {
            addCriterion("AppKey between", value1, value2, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppkeyNotBetween(String value1, String value2) {
            addCriterion("AppKey not between", value1, value2, "appkey");
            return (Criteria) this;
        }

        public Criteria andAppsecretIsNull() {
            addCriterion("AppSecret is null");
            return (Criteria) this;
        }

        public Criteria andAppsecretIsNotNull() {
            addCriterion("AppSecret is not null");
            return (Criteria) this;
        }

        public Criteria andAppsecretEqualTo(String value) {
            addCriterion("AppSecret =", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretNotEqualTo(String value) {
            addCriterion("AppSecret <>", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretGreaterThan(String value) {
            addCriterion("AppSecret >", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretGreaterThanOrEqualTo(String value) {
            addCriterion("AppSecret >=", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretLessThan(String value) {
            addCriterion("AppSecret <", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretLessThanOrEqualTo(String value) {
            addCriterion("AppSecret <=", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretLike(String value) {
            addCriterion("AppSecret like", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretNotLike(String value) {
            addCriterion("AppSecret not like", value, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretIn(List<String> values) {
            addCriterion("AppSecret in", values, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretNotIn(List<String> values) {
            addCriterion("AppSecret not in", values, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretBetween(String value1, String value2) {
            addCriterion("AppSecret between", value1, value2, "appsecret");
            return (Criteria) this;
        }

        public Criteria andAppsecretNotBetween(String value1, String value2) {
            addCriterion("AppSecret not between", value1, value2, "appsecret");
            return (Criteria) this;
        }

        public Criteria andBsubaccountIsNull() {
            addCriterion("bSubAccount is null");
            return (Criteria) this;
        }

        public Criteria andBsubaccountIsNotNull() {
            addCriterion("bSubAccount is not null");
            return (Criteria) this;
        }

        public Criteria andBsubaccountEqualTo(Boolean value) {
            addCriterion("bSubAccount =", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountNotEqualTo(Boolean value) {
            addCriterion("bSubAccount <>", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountGreaterThan(Boolean value) {
            addCriterion("bSubAccount >", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bSubAccount >=", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountLessThan(Boolean value) {
            addCriterion("bSubAccount <", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountLessThanOrEqualTo(Boolean value) {
            addCriterion("bSubAccount <=", value, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountIn(List<Boolean> values) {
            addCriterion("bSubAccount in", values, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountNotIn(List<Boolean> values) {
            addCriterion("bSubAccount not in", values, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountBetween(Boolean value1, Boolean value2) {
            addCriterion("bSubAccount between", value1, value2, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andBsubaccountNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bSubAccount not between", value1, value2, "bsubaccount");
            return (Criteria) this;
        }

        public Criteria andChargetypeIsNull() {
            addCriterion("ChargeType is null");
            return (Criteria) this;
        }

        public Criteria andChargetypeIsNotNull() {
            addCriterion("ChargeType is not null");
            return (Criteria) this;
        }

        public Criteria andChargetypeEqualTo(String value) {
            addCriterion("ChargeType =", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeNotEqualTo(String value) {
            addCriterion("ChargeType <>", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeGreaterThan(String value) {
            addCriterion("ChargeType >", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeGreaterThanOrEqualTo(String value) {
            addCriterion("ChargeType >=", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeLessThan(String value) {
            addCriterion("ChargeType <", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeLessThanOrEqualTo(String value) {
            addCriterion("ChargeType <=", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeLike(String value) {
            addCriterion("ChargeType like", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeNotLike(String value) {
            addCriterion("ChargeType not like", value, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeIn(List<String> values) {
            addCriterion("ChargeType in", values, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeNotIn(List<String> values) {
            addCriterion("ChargeType not in", values, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeBetween(String value1, String value2) {
            addCriterion("ChargeType between", value1, value2, "chargetype");
            return (Criteria) this;
        }

        public Criteria andChargetypeNotBetween(String value1, String value2) {
            addCriterion("ChargeType not between", value1, value2, "chargetype");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("AccountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("AccountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("AccountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("AccountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("AccountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("AccountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("AccountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("AccountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("AccountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("AccountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("AccountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("AccountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andUidIsNull() {
            addCriterion("uID is null");
            return (Criteria) this;
        }

        public Criteria andUidIsNotNull() {
            addCriterion("uID is not null");
            return (Criteria) this;
        }

        public Criteria andUidEqualTo(String value) {
            addCriterion("uID =", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotEqualTo(String value) {
            addCriterion("uID <>", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThan(String value) {
            addCriterion("uID >", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThanOrEqualTo(String value) {
            addCriterion("uID >=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThan(String value) {
            addCriterion("uID <", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThanOrEqualTo(String value) {
            addCriterion("uID <=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLike(String value) {
            addCriterion("uID like", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotLike(String value) {
            addCriterion("uID not like", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidIn(List<String> values) {
            addCriterion("uID in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotIn(List<String> values) {
            addCriterion("uID not in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidBetween(String value1, String value2) {
            addCriterion("uID between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotBetween(String value1, String value2) {
            addCriterion("uID not between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidIsNull() {
            addCriterion("WareHouseID is null");
            return (Criteria) this;
        }

        public Criteria andWarehouseidIsNotNull() {
            addCriterion("WareHouseID is not null");
            return (Criteria) this;
        }

        public Criteria andWarehouseidEqualTo(Integer value) {
            addCriterion("WareHouseID =", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotEqualTo(Integer value) {
            addCriterion("WareHouseID <>", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidGreaterThan(Integer value) {
            addCriterion("WareHouseID >", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidGreaterThanOrEqualTo(Integer value) {
            addCriterion("WareHouseID >=", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidLessThan(Integer value) {
            addCriterion("WareHouseID <", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidLessThanOrEqualTo(Integer value) {
            addCriterion("WareHouseID <=", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidIn(List<Integer> values) {
            addCriterion("WareHouseID in", values, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotIn(List<Integer> values) {
            addCriterion("WareHouseID not in", values, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidBetween(Integer value1, Integer value2) {
            addCriterion("WareHouseID between", value1, value2, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotBetween(Integer value1, Integer value2) {
            addCriterion("WareHouseID not between", value1, value2, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andContainfxIsNull() {
            addCriterion("ContainFX is null");
            return (Criteria) this;
        }

        public Criteria andContainfxIsNotNull() {
            addCriterion("ContainFX is not null");
            return (Criteria) this;
        }

        public Criteria andContainfxEqualTo(Integer value) {
            addCriterion("ContainFX =", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxNotEqualTo(Integer value) {
            addCriterion("ContainFX <>", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxGreaterThan(Integer value) {
            addCriterion("ContainFX >", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxGreaterThanOrEqualTo(Integer value) {
            addCriterion("ContainFX >=", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxLessThan(Integer value) {
            addCriterion("ContainFX <", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxLessThanOrEqualTo(Integer value) {
            addCriterion("ContainFX <=", value, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxIn(List<Integer> values) {
            addCriterion("ContainFX in", values, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxNotIn(List<Integer> values) {
            addCriterion("ContainFX not in", values, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxBetween(Integer value1, Integer value2) {
            addCriterion("ContainFX between", value1, value2, "containfx");
            return (Criteria) this;
        }

        public Criteria andContainfxNotBetween(Integer value1, Integer value2) {
            addCriterion("ContainFX not between", value1, value2, "containfx");
            return (Criteria) this;
        }

        public Criteria andKey3IsNull() {
            addCriterion("Key3 is null");
            return (Criteria) this;
        }

        public Criteria andKey3IsNotNull() {
            addCriterion("Key3 is not null");
            return (Criteria) this;
        }

        public Criteria andKey3EqualTo(String value) {
            addCriterion("Key3 =", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3NotEqualTo(String value) {
            addCriterion("Key3 <>", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3GreaterThan(String value) {
            addCriterion("Key3 >", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3GreaterThanOrEqualTo(String value) {
            addCriterion("Key3 >=", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3LessThan(String value) {
            addCriterion("Key3 <", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3LessThanOrEqualTo(String value) {
            addCriterion("Key3 <=", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3Like(String value) {
            addCriterion("Key3 like", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3NotLike(String value) {
            addCriterion("Key3 not like", value, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3In(List<String> values) {
            addCriterion("Key3 in", values, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3NotIn(List<String> values) {
            addCriterion("Key3 not in", values, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3Between(String value1, String value2) {
            addCriterion("Key3 between", value1, value2, "key3");
            return (Criteria) this;
        }

        public Criteria andKey3NotBetween(String value1, String value2) {
            addCriterion("Key3 not between", value1, value2, "key3");
            return (Criteria) this;
        }

        public Criteria andKey4IsNull() {
            addCriterion("key4 is null");
            return (Criteria) this;
        }

        public Criteria andKey4IsNotNull() {
            addCriterion("key4 is not null");
            return (Criteria) this;
        }

        public Criteria andKey4EqualTo(String value) {
            addCriterion("key4 =", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4NotEqualTo(String value) {
            addCriterion("key4 <>", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4GreaterThan(String value) {
            addCriterion("key4 >", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4GreaterThanOrEqualTo(String value) {
            addCriterion("key4 >=", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4LessThan(String value) {
            addCriterion("key4 <", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4LessThanOrEqualTo(String value) {
            addCriterion("key4 <=", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4Like(String value) {
            addCriterion("key4 like", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4NotLike(String value) {
            addCriterion("key4 not like", value, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4In(List<String> values) {
            addCriterion("key4 in", values, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4NotIn(List<String> values) {
            addCriterion("key4 not in", values, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4Between(String value1, String value2) {
            addCriterion("key4 between", value1, value2, "key4");
            return (Criteria) this;
        }

        public Criteria andKey4NotBetween(String value1, String value2) {
            addCriterion("key4 not between", value1, value2, "key4");
            return (Criteria) this;
        }

        public Criteria andSetapiIsNull() {
            addCriterion("SetAPI is null");
            return (Criteria) this;
        }

        public Criteria andSetapiIsNotNull() {
            addCriterion("SetAPI is not null");
            return (Criteria) this;
        }

        public Criteria andSetapiEqualTo(Boolean value) {
            addCriterion("SetAPI =", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiNotEqualTo(Boolean value) {
            addCriterion("SetAPI <>", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiGreaterThan(Boolean value) {
            addCriterion("SetAPI >", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiGreaterThanOrEqualTo(Boolean value) {
            addCriterion("SetAPI >=", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiLessThan(Boolean value) {
            addCriterion("SetAPI <", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiLessThanOrEqualTo(Boolean value) {
            addCriterion("SetAPI <=", value, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiIn(List<Boolean> values) {
            addCriterion("SetAPI in", values, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiNotIn(List<Boolean> values) {
            addCriterion("SetAPI not in", values, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiBetween(Boolean value1, Boolean value2) {
            addCriterion("SetAPI between", value1, value2, "setapi");
            return (Criteria) this;
        }

        public Criteria andSetapiNotBetween(Boolean value1, Boolean value2) {
            addCriterion("SetAPI not between", value1, value2, "setapi");
            return (Criteria) this;
        }

        public Criteria andSellnickIsNull() {
            addCriterion("SellNick is null");
            return (Criteria) this;
        }

        public Criteria andSellnickIsNotNull() {
            addCriterion("SellNick is not null");
            return (Criteria) this;
        }

        public Criteria andSellnickEqualTo(String value) {
            addCriterion("SellNick =", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickNotEqualTo(String value) {
            addCriterion("SellNick <>", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickGreaterThan(String value) {
            addCriterion("SellNick >", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickGreaterThanOrEqualTo(String value) {
            addCriterion("SellNick >=", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickLessThan(String value) {
            addCriterion("SellNick <", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickLessThanOrEqualTo(String value) {
            addCriterion("SellNick <=", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickLike(String value) {
            addCriterion("SellNick like", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickNotLike(String value) {
            addCriterion("SellNick not like", value, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickIn(List<String> values) {
            addCriterion("SellNick in", values, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickNotIn(List<String> values) {
            addCriterion("SellNick not in", values, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickBetween(String value1, String value2) {
            addCriterion("SellNick between", value1, value2, "sellnick");
            return (Criteria) this;
        }

        public Criteria andSellnickNotBetween(String value1, String value2) {
            addCriterion("SellNick not between", value1, value2, "sellnick");
            return (Criteria) this;
        }

        public Criteria andBsysstockIsNull() {
            addCriterion("bSysStock is null");
            return (Criteria) this;
        }

        public Criteria andBsysstockIsNotNull() {
            addCriterion("bSysStock is not null");
            return (Criteria) this;
        }

        public Criteria andBsysstockEqualTo(Boolean value) {
            addCriterion("bSysStock =", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockNotEqualTo(Boolean value) {
            addCriterion("bSysStock <>", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockGreaterThan(Boolean value) {
            addCriterion("bSysStock >", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bSysStock >=", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockLessThan(Boolean value) {
            addCriterion("bSysStock <", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockLessThanOrEqualTo(Boolean value) {
            addCriterion("bSysStock <=", value, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockIn(List<Boolean> values) {
            addCriterion("bSysStock in", values, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockNotIn(List<Boolean> values) {
            addCriterion("bSysStock not in", values, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockBetween(Boolean value1, Boolean value2) {
            addCriterion("bSysStock between", value1, value2, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bSysStock not between", value1, value2, "bsysstock");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxIsNull() {
            addCriterion("bSysStockFx is null");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxIsNotNull() {
            addCriterion("bSysStockFx is not null");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxEqualTo(Boolean value) {
            addCriterion("bSysStockFx =", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxNotEqualTo(Boolean value) {
            addCriterion("bSysStockFx <>", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxGreaterThan(Boolean value) {
            addCriterion("bSysStockFx >", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bSysStockFx >=", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxLessThan(Boolean value) {
            addCriterion("bSysStockFx <", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxLessThanOrEqualTo(Boolean value) {
            addCriterion("bSysStockFx <=", value, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxIn(List<Boolean> values) {
            addCriterion("bSysStockFx in", values, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxNotIn(List<Boolean> values) {
            addCriterion("bSysStockFx not in", values, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxBetween(Boolean value1, Boolean value2) {
            addCriterion("bSysStockFx between", value1, value2, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andBsysstockfxNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bSysStockFx not between", value1, value2, "bsysstockfx");
            return (Criteria) this;
        }

        public Criteria andUpdateageIsNull() {
            addCriterion("UpdateAge is null");
            return (Criteria) this;
        }

        public Criteria andUpdateageIsNotNull() {
            addCriterion("UpdateAge is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateageEqualTo(BigDecimal value) {
            addCriterion("UpdateAge =", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageNotEqualTo(BigDecimal value) {
            addCriterion("UpdateAge <>", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageGreaterThan(BigDecimal value) {
            addCriterion("UpdateAge >", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("UpdateAge >=", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageLessThan(BigDecimal value) {
            addCriterion("UpdateAge <", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageLessThanOrEqualTo(BigDecimal value) {
            addCriterion("UpdateAge <=", value, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageIn(List<BigDecimal> values) {
            addCriterion("UpdateAge in", values, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageNotIn(List<BigDecimal> values) {
            addCriterion("UpdateAge not in", values, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpdateAge between", value1, value2, "updateage");
            return (Criteria) this;
        }

        public Criteria andUpdateageNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("UpdateAge not between", value1, value2, "updateage");
            return (Criteria) this;
        }

        public Criteria andSyswareIsNull() {
            addCriterion("SysWare is null");
            return (Criteria) this;
        }

        public Criteria andSyswareIsNotNull() {
            addCriterion("SysWare is not null");
            return (Criteria) this;
        }

        public Criteria andSyswareEqualTo(Integer value) {
            addCriterion("SysWare =", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareNotEqualTo(Integer value) {
            addCriterion("SysWare <>", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareGreaterThan(Integer value) {
            addCriterion("SysWare >", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareGreaterThanOrEqualTo(Integer value) {
            addCriterion("SysWare >=", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareLessThan(Integer value) {
            addCriterion("SysWare <", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareLessThanOrEqualTo(Integer value) {
            addCriterion("SysWare <=", value, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareIn(List<Integer> values) {
            addCriterion("SysWare in", values, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareNotIn(List<Integer> values) {
            addCriterion("SysWare not in", values, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareBetween(Integer value1, Integer value2) {
            addCriterion("SysWare between", value1, value2, "sysware");
            return (Criteria) this;
        }

        public Criteria andSyswareNotBetween(Integer value1, Integer value2) {
            addCriterion("SysWare not between", value1, value2, "sysware");
            return (Criteria) this;
        }

        public Criteria andBchkstatusIsNull() {
            addCriterion("bCHKStatus is null");
            return (Criteria) this;
        }

        public Criteria andBchkstatusIsNotNull() {
            addCriterion("bCHKStatus is not null");
            return (Criteria) this;
        }

        public Criteria andBchkstatusEqualTo(Byte value) {
            addCriterion("bCHKStatus =", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusNotEqualTo(Byte value) {
            addCriterion("bCHKStatus <>", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusGreaterThan(Byte value) {
            addCriterion("bCHKStatus >", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("bCHKStatus >=", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusLessThan(Byte value) {
            addCriterion("bCHKStatus <", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusLessThanOrEqualTo(Byte value) {
            addCriterion("bCHKStatus <=", value, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusIn(List<Byte> values) {
            addCriterion("bCHKStatus in", values, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusNotIn(List<Byte> values) {
            addCriterion("bCHKStatus not in", values, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusBetween(Byte value1, Byte value2) {
            addCriterion("bCHKStatus between", value1, value2, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkstatusNotBetween(Byte value1, Byte value2) {
            addCriterion("bCHKStatus not between", value1, value2, "bchkstatus");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkIsNull() {
            addCriterion("bCHKBuyerRemark is null");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkIsNotNull() {
            addCriterion("bCHKBuyerRemark is not null");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkEqualTo(Boolean value) {
            addCriterion("bCHKBuyerRemark =", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkNotEqualTo(Boolean value) {
            addCriterion("bCHKBuyerRemark <>", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkGreaterThan(Boolean value) {
            addCriterion("bCHKBuyerRemark >", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bCHKBuyerRemark >=", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkLessThan(Boolean value) {
            addCriterion("bCHKBuyerRemark <", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkLessThanOrEqualTo(Boolean value) {
            addCriterion("bCHKBuyerRemark <=", value, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkIn(List<Boolean> values) {
            addCriterion("bCHKBuyerRemark in", values, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkNotIn(List<Boolean> values) {
            addCriterion("bCHKBuyerRemark not in", values, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkBetween(Boolean value1, Boolean value2) {
            addCriterion("bCHKBuyerRemark between", value1, value2, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andBchkbuyerremarkNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bCHKBuyerRemark not between", value1, value2, "bchkbuyerremark");
            return (Criteria) this;
        }

        public Criteria andSessionkeyIsNull() {
            addCriterion("SessionKey is null");
            return (Criteria) this;
        }

        public Criteria andSessionkeyIsNotNull() {
            addCriterion("SessionKey is not null");
            return (Criteria) this;
        }

        public Criteria andSessionkeyEqualTo(String value) {
            addCriterion("SessionKey =", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyNotEqualTo(String value) {
            addCriterion("SessionKey <>", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyGreaterThan(String value) {
            addCriterion("SessionKey >", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyGreaterThanOrEqualTo(String value) {
            addCriterion("SessionKey >=", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyLessThan(String value) {
            addCriterion("SessionKey <", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyLessThanOrEqualTo(String value) {
            addCriterion("SessionKey <=", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyLike(String value) {
            addCriterion("SessionKey like", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyNotLike(String value) {
            addCriterion("SessionKey not like", value, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyIn(List<String> values) {
            addCriterion("SessionKey in", values, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyNotIn(List<String> values) {
            addCriterion("SessionKey not in", values, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyBetween(String value1, String value2) {
            addCriterion("SessionKey between", value1, value2, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessionkeyNotBetween(String value1, String value2) {
            addCriterion("SessionKey not between", value1, value2, "sessionkey");
            return (Criteria) this;
        }

        public Criteria andSessiondateIsNull() {
            addCriterion("SessionDate is null");
            return (Criteria) this;
        }

        public Criteria andSessiondateIsNotNull() {
            addCriterion("SessionDate is not null");
            return (Criteria) this;
        }

        public Criteria andSessiondateEqualTo(Date value) {
            addCriterion("SessionDate =", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateNotEqualTo(Date value) {
            addCriterion("SessionDate <>", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateGreaterThan(Date value) {
            addCriterion("SessionDate >", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateGreaterThanOrEqualTo(Date value) {
            addCriterion("SessionDate >=", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateLessThan(Date value) {
            addCriterion("SessionDate <", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateLessThanOrEqualTo(Date value) {
            addCriterion("SessionDate <=", value, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateIn(List<Date> values) {
            addCriterion("SessionDate in", values, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateNotIn(List<Date> values) {
            addCriterion("SessionDate not in", values, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateBetween(Date value1, Date value2) {
            addCriterion("SessionDate between", value1, value2, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andSessiondateNotBetween(Date value1, Date value2) {
            addCriterion("SessionDate not between", value1, value2, "sessiondate");
            return (Criteria) this;
        }

        public Criteria andExpiredateIsNull() {
            addCriterion("expiredate is null");
            return (Criteria) this;
        }

        public Criteria andExpiredateIsNotNull() {
            addCriterion("expiredate is not null");
            return (Criteria) this;
        }

        public Criteria andExpiredateEqualTo(Date value) {
            addCriterion("expiredate =", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateNotEqualTo(Date value) {
            addCriterion("expiredate <>", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateGreaterThan(Date value) {
            addCriterion("expiredate >", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateGreaterThanOrEqualTo(Date value) {
            addCriterion("expiredate >=", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateLessThan(Date value) {
            addCriterion("expiredate <", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateLessThanOrEqualTo(Date value) {
            addCriterion("expiredate <=", value, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateIn(List<Date> values) {
            addCriterion("expiredate in", values, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateNotIn(List<Date> values) {
            addCriterion("expiredate not in", values, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateBetween(Date value1, Date value2) {
            addCriterion("expiredate between", value1, value2, "expiredate");
            return (Criteria) this;
        }

        public Criteria andExpiredateNotBetween(Date value1, Date value2) {
            addCriterion("expiredate not between", value1, value2, "expiredate");
            return (Criteria) this;
        }

        public Criteria andTbinctimeIsNull() {
            addCriterion("TBIncTime is null");
            return (Criteria) this;
        }

        public Criteria andTbinctimeIsNotNull() {
            addCriterion("TBIncTime is not null");
            return (Criteria) this;
        }

        public Criteria andTbinctimeEqualTo(Date value) {
            addCriterion("TBIncTime =", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeNotEqualTo(Date value) {
            addCriterion("TBIncTime <>", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeGreaterThan(Date value) {
            addCriterion("TBIncTime >", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeGreaterThanOrEqualTo(Date value) {
            addCriterion("TBIncTime >=", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeLessThan(Date value) {
            addCriterion("TBIncTime <", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeLessThanOrEqualTo(Date value) {
            addCriterion("TBIncTime <=", value, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeIn(List<Date> values) {
            addCriterion("TBIncTime in", values, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeNotIn(List<Date> values) {
            addCriterion("TBIncTime not in", values, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeBetween(Date value1, Date value2) {
            addCriterion("TBIncTime between", value1, value2, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andTbinctimeNotBetween(Date value1, Date value2) {
            addCriterion("TBIncTime not between", value1, value2, "tbinctime");
            return (Criteria) this;
        }

        public Criteria andBincgetIsNull() {
            addCriterion("bIncGet is null");
            return (Criteria) this;
        }

        public Criteria andBincgetIsNotNull() {
            addCriterion("bIncGet is not null");
            return (Criteria) this;
        }

        public Criteria andBincgetEqualTo(Boolean value) {
            addCriterion("bIncGet =", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetNotEqualTo(Boolean value) {
            addCriterion("bIncGet <>", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetGreaterThan(Boolean value) {
            addCriterion("bIncGet >", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bIncGet >=", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetLessThan(Boolean value) {
            addCriterion("bIncGet <", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetLessThanOrEqualTo(Boolean value) {
            addCriterion("bIncGet <=", value, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetIn(List<Boolean> values) {
            addCriterion("bIncGet in", values, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetNotIn(List<Boolean> values) {
            addCriterion("bIncGet not in", values, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetBetween(Boolean value1, Boolean value2) {
            addCriterion("bIncGet between", value1, value2, "bincget");
            return (Criteria) this;
        }

        public Criteria andBincgetNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bIncGet not between", value1, value2, "bincget");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseIsNull() {
            addCriterion("SysWareHouse is null");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseIsNotNull() {
            addCriterion("SysWareHouse is not null");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseEqualTo(String value) {
            addCriterion("SysWareHouse =", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseNotEqualTo(String value) {
            addCriterion("SysWareHouse <>", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseGreaterThan(String value) {
            addCriterion("SysWareHouse >", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseGreaterThanOrEqualTo(String value) {
            addCriterion("SysWareHouse >=", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseLessThan(String value) {
            addCriterion("SysWareHouse <", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseLessThanOrEqualTo(String value) {
            addCriterion("SysWareHouse <=", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseLike(String value) {
            addCriterion("SysWareHouse like", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseNotLike(String value) {
            addCriterion("SysWareHouse not like", value, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseIn(List<String> values) {
            addCriterion("SysWareHouse in", values, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseNotIn(List<String> values) {
            addCriterion("SysWareHouse not in", values, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseBetween(String value1, String value2) {
            addCriterion("SysWareHouse between", value1, value2, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyswarehouseNotBetween(String value1, String value2) {
            addCriterion("SysWareHouse not between", value1, value2, "syswarehouse");
            return (Criteria) this;
        }

        public Criteria andSyspercentageIsNull() {
            addCriterion("SysPercentage is null");
            return (Criteria) this;
        }

        public Criteria andSyspercentageIsNotNull() {
            addCriterion("SysPercentage is not null");
            return (Criteria) this;
        }

        public Criteria andSyspercentageEqualTo(Integer value) {
            addCriterion("SysPercentage =", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageNotEqualTo(Integer value) {
            addCriterion("SysPercentage <>", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageGreaterThan(Integer value) {
            addCriterion("SysPercentage >", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageGreaterThanOrEqualTo(Integer value) {
            addCriterion("SysPercentage >=", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageLessThan(Integer value) {
            addCriterion("SysPercentage <", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageLessThanOrEqualTo(Integer value) {
            addCriterion("SysPercentage <=", value, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageIn(List<Integer> values) {
            addCriterion("SysPercentage in", values, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageNotIn(List<Integer> values) {
            addCriterion("SysPercentage not in", values, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageBetween(Integer value1, Integer value2) {
            addCriterion("SysPercentage between", value1, value2, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andSyspercentageNotBetween(Integer value1, Integer value2) {
            addCriterion("SysPercentage not between", value1, value2, "syspercentage");
            return (Criteria) this;
        }

        public Criteria andAutogettimeIsNull() {
            addCriterion("AutoGetTime is null");
            return (Criteria) this;
        }

        public Criteria andAutogettimeIsNotNull() {
            addCriterion("AutoGetTime is not null");
            return (Criteria) this;
        }

        public Criteria andAutogettimeEqualTo(Date value) {
            addCriterion("AutoGetTime =", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeNotEqualTo(Date value) {
            addCriterion("AutoGetTime <>", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeGreaterThan(Date value) {
            addCriterion("AutoGetTime >", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeGreaterThanOrEqualTo(Date value) {
            addCriterion("AutoGetTime >=", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeLessThan(Date value) {
            addCriterion("AutoGetTime <", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeLessThanOrEqualTo(Date value) {
            addCriterion("AutoGetTime <=", value, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeIn(List<Date> values) {
            addCriterion("AutoGetTime in", values, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeNotIn(List<Date> values) {
            addCriterion("AutoGetTime not in", values, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeBetween(Date value1, Date value2) {
            addCriterion("AutoGetTime between", value1, value2, "autogettime");
            return (Criteria) this;
        }

        public Criteria andAutogettimeNotBetween(Date value1, Date value2) {
            addCriterion("AutoGetTime not between", value1, value2, "autogettime");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("UserID is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("UserID is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(String value) {
            addCriterion("UserID =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(String value) {
            addCriterion("UserID <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(String value) {
            addCriterion("UserID >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(String value) {
            addCriterion("UserID >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(String value) {
            addCriterion("UserID <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(String value) {
            addCriterion("UserID <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLike(String value) {
            addCriterion("UserID like", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotLike(String value) {
            addCriterion("UserID not like", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<String> values) {
            addCriterion("UserID in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<String> values) {
            addCriterion("UserID not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(String value1, String value2) {
            addCriterion("UserID between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(String value1, String value2) {
            addCriterion("UserID not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseripIsNull() {
            addCriterion("UserIP is null");
            return (Criteria) this;
        }

        public Criteria andUseripIsNotNull() {
            addCriterion("UserIP is not null");
            return (Criteria) this;
        }

        public Criteria andUseripEqualTo(String value) {
            addCriterion("UserIP =", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripNotEqualTo(String value) {
            addCriterion("UserIP <>", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripGreaterThan(String value) {
            addCriterion("UserIP >", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripGreaterThanOrEqualTo(String value) {
            addCriterion("UserIP >=", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripLessThan(String value) {
            addCriterion("UserIP <", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripLessThanOrEqualTo(String value) {
            addCriterion("UserIP <=", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripLike(String value) {
            addCriterion("UserIP like", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripNotLike(String value) {
            addCriterion("UserIP not like", value, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripIn(List<String> values) {
            addCriterion("UserIP in", values, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripNotIn(List<String> values) {
            addCriterion("UserIP not in", values, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripBetween(String value1, String value2) {
            addCriterion("UserIP between", value1, value2, "userip");
            return (Criteria) this;
        }

        public Criteria andUseripNotBetween(String value1, String value2) {
            addCriterion("UserIP not between", value1, value2, "userip");
            return (Criteria) this;
        }

        public Criteria andCustomeridIsNull() {
            addCriterion("customerID is null");
            return (Criteria) this;
        }

        public Criteria andCustomeridIsNotNull() {
            addCriterion("customerID is not null");
            return (Criteria) this;
        }

        public Criteria andCustomeridEqualTo(Integer value) {
            addCriterion("customerID =", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridNotEqualTo(Integer value) {
            addCriterion("customerID <>", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridGreaterThan(Integer value) {
            addCriterion("customerID >", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridGreaterThanOrEqualTo(Integer value) {
            addCriterion("customerID >=", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridLessThan(Integer value) {
            addCriterion("customerID <", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridLessThanOrEqualTo(Integer value) {
            addCriterion("customerID <=", value, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridIn(List<Integer> values) {
            addCriterion("customerID in", values, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridNotIn(List<Integer> values) {
            addCriterion("customerID not in", values, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridBetween(Integer value1, Integer value2) {
            addCriterion("customerID between", value1, value2, "customerid");
            return (Criteria) this;
        }

        public Criteria andCustomeridNotBetween(Integer value1, Integer value2) {
            addCriterion("customerID not between", value1, value2, "customerid");
            return (Criteria) this;
        }

        public Criteria andDdprintIsNull() {
            addCriterion("DDPrint is null");
            return (Criteria) this;
        }

        public Criteria andDdprintIsNotNull() {
            addCriterion("DDPrint is not null");
            return (Criteria) this;
        }

        public Criteria andDdprintEqualTo(Boolean value) {
            addCriterion("DDPrint =", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintNotEqualTo(Boolean value) {
            addCriterion("DDPrint <>", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintGreaterThan(Boolean value) {
            addCriterion("DDPrint >", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintGreaterThanOrEqualTo(Boolean value) {
            addCriterion("DDPrint >=", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintLessThan(Boolean value) {
            addCriterion("DDPrint <", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintLessThanOrEqualTo(Boolean value) {
            addCriterion("DDPrint <=", value, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintIn(List<Boolean> values) {
            addCriterion("DDPrint in", values, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintNotIn(List<Boolean> values) {
            addCriterion("DDPrint not in", values, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintBetween(Boolean value1, Boolean value2) {
            addCriterion("DDPrint between", value1, value2, "ddprint");
            return (Criteria) this;
        }

        public Criteria andDdprintNotBetween(Boolean value1, Boolean value2) {
            addCriterion("DDPrint not between", value1, value2, "ddprint");
            return (Criteria) this;
        }

        public Criteria andBrdspullIsNull() {
            addCriterion("bRDSPull is null");
            return (Criteria) this;
        }

        public Criteria andBrdspullIsNotNull() {
            addCriterion("bRDSPull is not null");
            return (Criteria) this;
        }

        public Criteria andBrdspullEqualTo(Boolean value) {
            addCriterion("bRDSPull =", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullNotEqualTo(Boolean value) {
            addCriterion("bRDSPull <>", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullGreaterThan(Boolean value) {
            addCriterion("bRDSPull >", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bRDSPull >=", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullLessThan(Boolean value) {
            addCriterion("bRDSPull <", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullLessThanOrEqualTo(Boolean value) {
            addCriterion("bRDSPull <=", value, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullIn(List<Boolean> values) {
            addCriterion("bRDSPull in", values, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullNotIn(List<Boolean> values) {
            addCriterion("bRDSPull not in", values, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullBetween(Boolean value1, Boolean value2) {
            addCriterion("bRDSPull between", value1, value2, "brdspull");
            return (Criteria) this;
        }

        public Criteria andBrdspullNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bRDSPull not between", value1, value2, "brdspull");
            return (Criteria) this;
        }

        public Criteria andRdstimeIsNull() {
            addCriterion("RDSTime is null");
            return (Criteria) this;
        }

        public Criteria andRdstimeIsNotNull() {
            addCriterion("RDSTime is not null");
            return (Criteria) this;
        }

        public Criteria andRdstimeEqualTo(Date value) {
            addCriterion("RDSTime =", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeNotEqualTo(Date value) {
            addCriterion("RDSTime <>", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeGreaterThan(Date value) {
            addCriterion("RDSTime >", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeGreaterThanOrEqualTo(Date value) {
            addCriterion("RDSTime >=", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeLessThan(Date value) {
            addCriterion("RDSTime <", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeLessThanOrEqualTo(Date value) {
            addCriterion("RDSTime <=", value, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeIn(List<Date> values) {
            addCriterion("RDSTime in", values, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeNotIn(List<Date> values) {
            addCriterion("RDSTime not in", values, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeBetween(Date value1, Date value2) {
            addCriterion("RDSTime between", value1, value2, "rdstime");
            return (Criteria) this;
        }

        public Criteria andRdstimeNotBetween(Date value1, Date value2) {
            addCriterion("RDSTime not between", value1, value2, "rdstime");
            return (Criteria) this;
        }

        public Criteria andAutogetdivIsNull() {
            addCriterion("AutoGetDiv is null");
            return (Criteria) this;
        }

        public Criteria andAutogetdivIsNotNull() {
            addCriterion("AutoGetDiv is not null");
            return (Criteria) this;
        }

        public Criteria andAutogetdivEqualTo(Integer value) {
            addCriterion("AutoGetDiv =", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivNotEqualTo(Integer value) {
            addCriterion("AutoGetDiv <>", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivGreaterThan(Integer value) {
            addCriterion("AutoGetDiv >", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivGreaterThanOrEqualTo(Integer value) {
            addCriterion("AutoGetDiv >=", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivLessThan(Integer value) {
            addCriterion("AutoGetDiv <", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivLessThanOrEqualTo(Integer value) {
            addCriterion("AutoGetDiv <=", value, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivIn(List<Integer> values) {
            addCriterion("AutoGetDiv in", values, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivNotIn(List<Integer> values) {
            addCriterion("AutoGetDiv not in", values, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivBetween(Integer value1, Integer value2) {
            addCriterion("AutoGetDiv between", value1, value2, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andAutogetdivNotBetween(Integer value1, Integer value2) {
            addCriterion("AutoGetDiv not between", value1, value2, "autogetdiv");
            return (Criteria) this;
        }

        public Criteria andBautogetIsNull() {
            addCriterion("bAutoGet is null");
            return (Criteria) this;
        }

        public Criteria andBautogetIsNotNull() {
            addCriterion("bAutoGet is not null");
            return (Criteria) this;
        }

        public Criteria andBautogetEqualTo(Boolean value) {
            addCriterion("bAutoGet =", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetNotEqualTo(Boolean value) {
            addCriterion("bAutoGet <>", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetGreaterThan(Boolean value) {
            addCriterion("bAutoGet >", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bAutoGet >=", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetLessThan(Boolean value) {
            addCriterion("bAutoGet <", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetLessThanOrEqualTo(Boolean value) {
            addCriterion("bAutoGet <=", value, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetIn(List<Boolean> values) {
            addCriterion("bAutoGet in", values, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetNotIn(List<Boolean> values) {
            addCriterion("bAutoGet not in", values, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetBetween(Boolean value1, Boolean value2) {
            addCriterion("bAutoGet between", value1, value2, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBautogetNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bAutoGet not between", value1, value2, "bautoget");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseIsNull() {
            addCriterion("bGetRefuse is null");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseIsNotNull() {
            addCriterion("bGetRefuse is not null");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseEqualTo(Boolean value) {
            addCriterion("bGetRefuse =", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseNotEqualTo(Boolean value) {
            addCriterion("bGetRefuse <>", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseGreaterThan(Boolean value) {
            addCriterion("bGetRefuse >", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bGetRefuse >=", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseLessThan(Boolean value) {
            addCriterion("bGetRefuse <", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseLessThanOrEqualTo(Boolean value) {
            addCriterion("bGetRefuse <=", value, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseIn(List<Boolean> values) {
            addCriterion("bGetRefuse in", values, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseNotIn(List<Boolean> values) {
            addCriterion("bGetRefuse not in", values, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseBetween(Boolean value1, Boolean value2) {
            addCriterion("bGetRefuse between", value1, value2, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bGetRefuse not between", value1, value2, "bgetrefuse");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderIsNull() {
            addCriterion("bGetRefuseOrder is null");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderIsNotNull() {
            addCriterion("bGetRefuseOrder is not null");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderEqualTo(Boolean value) {
            addCriterion("bGetRefuseOrder =", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderNotEqualTo(Boolean value) {
            addCriterion("bGetRefuseOrder <>", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderGreaterThan(Boolean value) {
            addCriterion("bGetRefuseOrder >", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bGetRefuseOrder >=", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderLessThan(Boolean value) {
            addCriterion("bGetRefuseOrder <", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderLessThanOrEqualTo(Boolean value) {
            addCriterion("bGetRefuseOrder <=", value, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderIn(List<Boolean> values) {
            addCriterion("bGetRefuseOrder in", values, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderNotIn(List<Boolean> values) {
            addCriterion("bGetRefuseOrder not in", values, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderBetween(Boolean value1, Boolean value2) {
            addCriterion("bGetRefuseOrder between", value1, value2, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andBgetrefuseorderNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bGetRefuseOrder not between", value1, value2, "bgetrefuseorder");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeIsNull() {
            addCriterion("RefuseIncTime is null");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeIsNotNull() {
            addCriterion("RefuseIncTime is not null");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeEqualTo(Date value) {
            addCriterion("RefuseIncTime =", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeNotEqualTo(Date value) {
            addCriterion("RefuseIncTime <>", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeGreaterThan(Date value) {
            addCriterion("RefuseIncTime >", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeGreaterThanOrEqualTo(Date value) {
            addCriterion("RefuseIncTime >=", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeLessThan(Date value) {
            addCriterion("RefuseIncTime <", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeLessThanOrEqualTo(Date value) {
            addCriterion("RefuseIncTime <=", value, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeIn(List<Date> values) {
            addCriterion("RefuseIncTime in", values, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeNotIn(List<Date> values) {
            addCriterion("RefuseIncTime not in", values, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeBetween(Date value1, Date value2) {
            addCriterion("RefuseIncTime between", value1, value2, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andRefuseinctimeNotBetween(Date value1, Date value2) {
            addCriterion("RefuseIncTime not between", value1, value2, "refuseinctime");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeIsNull() {
            addCriterion("jdcustcode is null");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeIsNotNull() {
            addCriterion("jdcustcode is not null");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeEqualTo(String value) {
            addCriterion("jdcustcode =", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeNotEqualTo(String value) {
            addCriterion("jdcustcode <>", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeGreaterThan(String value) {
            addCriterion("jdcustcode >", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeGreaterThanOrEqualTo(String value) {
            addCriterion("jdcustcode >=", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeLessThan(String value) {
            addCriterion("jdcustcode <", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeLessThanOrEqualTo(String value) {
            addCriterion("jdcustcode <=", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeLike(String value) {
            addCriterion("jdcustcode like", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeNotLike(String value) {
            addCriterion("jdcustcode not like", value, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeIn(List<String> values) {
            addCriterion("jdcustcode in", values, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeNotIn(List<String> values) {
            addCriterion("jdcustcode not in", values, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeBetween(String value1, String value2) {
            addCriterion("jdcustcode between", value1, value2, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andJdcustcodeNotBetween(String value1, String value2) {
            addCriterion("jdcustcode not between", value1, value2, "jdcustcode");
            return (Criteria) this;
        }

        public Criteria andBcccIsNull() {
            addCriterion("bccc is null");
            return (Criteria) this;
        }

        public Criteria andBcccIsNotNull() {
            addCriterion("bccc is not null");
            return (Criteria) this;
        }

        public Criteria andBcccEqualTo(Boolean value) {
            addCriterion("bccc =", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccNotEqualTo(Boolean value) {
            addCriterion("bccc <>", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccGreaterThan(Boolean value) {
            addCriterion("bccc >", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bccc >=", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccLessThan(Boolean value) {
            addCriterion("bccc <", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccLessThanOrEqualTo(Boolean value) {
            addCriterion("bccc <=", value, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccIn(List<Boolean> values) {
            addCriterion("bccc in", values, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccNotIn(List<Boolean> values) {
            addCriterion("bccc not in", values, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccBetween(Boolean value1, Boolean value2) {
            addCriterion("bccc between", value1, value2, "bccc");
            return (Criteria) this;
        }

        public Criteria andBcccNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bccc not between", value1, value2, "bccc");
            return (Criteria) this;
        }

        public Criteria andRdschannelIsNull() {
            addCriterion("rdsChannel is null");
            return (Criteria) this;
        }

        public Criteria andRdschannelIsNotNull() {
            addCriterion("rdsChannel is not null");
            return (Criteria) this;
        }

        public Criteria andRdschannelEqualTo(Integer value) {
            addCriterion("rdsChannel =", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelNotEqualTo(Integer value) {
            addCriterion("rdsChannel <>", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelGreaterThan(Integer value) {
            addCriterion("rdsChannel >", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelGreaterThanOrEqualTo(Integer value) {
            addCriterion("rdsChannel >=", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelLessThan(Integer value) {
            addCriterion("rdsChannel <", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelLessThanOrEqualTo(Integer value) {
            addCriterion("rdsChannel <=", value, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelIn(List<Integer> values) {
            addCriterion("rdsChannel in", values, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelNotIn(List<Integer> values) {
            addCriterion("rdsChannel not in", values, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelBetween(Integer value1, Integer value2) {
            addCriterion("rdsChannel between", value1, value2, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andRdschannelNotBetween(Integer value1, Integer value2) {
            addCriterion("rdsChannel not between", value1, value2, "rdschannel");
            return (Criteria) this;
        }

        public Criteria andSetextIsNull() {
            addCriterion("setext is null");
            return (Criteria) this;
        }

        public Criteria andSetextIsNotNull() {
            addCriterion("setext is not null");
            return (Criteria) this;
        }

        public Criteria andSetextEqualTo(String value) {
            addCriterion("setext =", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextNotEqualTo(String value) {
            addCriterion("setext <>", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextGreaterThan(String value) {
            addCriterion("setext >", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextGreaterThanOrEqualTo(String value) {
            addCriterion("setext >=", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextLessThan(String value) {
            addCriterion("setext <", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextLessThanOrEqualTo(String value) {
            addCriterion("setext <=", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextLike(String value) {
            addCriterion("setext like", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextNotLike(String value) {
            addCriterion("setext not like", value, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextIn(List<String> values) {
            addCriterion("setext in", values, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextNotIn(List<String> values) {
            addCriterion("setext not in", values, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextBetween(String value1, String value2) {
            addCriterion("setext between", value1, value2, "setext");
            return (Criteria) this;
        }

        public Criteria andSetextNotBetween(String value1, String value2) {
            addCriterion("setext not between", value1, value2, "setext");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckIsNull() {
            addCriterion("bWLBCheck is null");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckIsNotNull() {
            addCriterion("bWLBCheck is not null");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckEqualTo(Boolean value) {
            addCriterion("bWLBCheck =", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckNotEqualTo(Boolean value) {
            addCriterion("bWLBCheck <>", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckGreaterThan(Boolean value) {
            addCriterion("bWLBCheck >", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bWLBCheck >=", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckLessThan(Boolean value) {
            addCriterion("bWLBCheck <", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckLessThanOrEqualTo(Boolean value) {
            addCriterion("bWLBCheck <=", value, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckIn(List<Boolean> values) {
            addCriterion("bWLBCheck in", values, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckNotIn(List<Boolean> values) {
            addCriterion("bWLBCheck not in", values, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckBetween(Boolean value1, Boolean value2) {
            addCriterion("bWLBCheck between", value1, value2, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andBwlbcheckNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bWLBCheck not between", value1, value2, "bwlbcheck");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenIsNull() {
            addCriterion("PayPalToken is null");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenIsNotNull() {
            addCriterion("PayPalToken is not null");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenEqualTo(String value) {
            addCriterion("PayPalToken =", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenNotEqualTo(String value) {
            addCriterion("PayPalToken <>", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenGreaterThan(String value) {
            addCriterion("PayPalToken >", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenGreaterThanOrEqualTo(String value) {
            addCriterion("PayPalToken >=", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenLessThan(String value) {
            addCriterion("PayPalToken <", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenLessThanOrEqualTo(String value) {
            addCriterion("PayPalToken <=", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenLike(String value) {
            addCriterion("PayPalToken like", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenNotLike(String value) {
            addCriterion("PayPalToken not like", value, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenIn(List<String> values) {
            addCriterion("PayPalToken in", values, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenNotIn(List<String> values) {
            addCriterion("PayPalToken not in", values, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenBetween(String value1, String value2) {
            addCriterion("PayPalToken between", value1, value2, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaltokenNotBetween(String value1, String value2) {
            addCriterion("PayPalToken not between", value1, value2, "paypaltoken");
            return (Criteria) this;
        }

        public Criteria andPaypaluserIsNull() {
            addCriterion("PayPalUser is null");
            return (Criteria) this;
        }

        public Criteria andPaypaluserIsNotNull() {
            addCriterion("PayPalUser is not null");
            return (Criteria) this;
        }

        public Criteria andPaypaluserEqualTo(String value) {
            addCriterion("PayPalUser =", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserNotEqualTo(String value) {
            addCriterion("PayPalUser <>", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserGreaterThan(String value) {
            addCriterion("PayPalUser >", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserGreaterThanOrEqualTo(String value) {
            addCriterion("PayPalUser >=", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserLessThan(String value) {
            addCriterion("PayPalUser <", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserLessThanOrEqualTo(String value) {
            addCriterion("PayPalUser <=", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserLike(String value) {
            addCriterion("PayPalUser like", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserNotLike(String value) {
            addCriterion("PayPalUser not like", value, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserIn(List<String> values) {
            addCriterion("PayPalUser in", values, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserNotIn(List<String> values) {
            addCriterion("PayPalUser not in", values, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserBetween(String value1, String value2) {
            addCriterion("PayPalUser between", value1, value2, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypaluserNotBetween(String value1, String value2) {
            addCriterion("PayPalUser not between", value1, value2, "paypaluser");
            return (Criteria) this;
        }

        public Criteria andPaypalpassIsNull() {
            addCriterion("PayPalPass is null");
            return (Criteria) this;
        }

        public Criteria andPaypalpassIsNotNull() {
            addCriterion("PayPalPass is not null");
            return (Criteria) this;
        }

        public Criteria andPaypalpassEqualTo(String value) {
            addCriterion("PayPalPass =", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassNotEqualTo(String value) {
            addCriterion("PayPalPass <>", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassGreaterThan(String value) {
            addCriterion("PayPalPass >", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassGreaterThanOrEqualTo(String value) {
            addCriterion("PayPalPass >=", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassLessThan(String value) {
            addCriterion("PayPalPass <", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassLessThanOrEqualTo(String value) {
            addCriterion("PayPalPass <=", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassLike(String value) {
            addCriterion("PayPalPass like", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassNotLike(String value) {
            addCriterion("PayPalPass not like", value, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassIn(List<String> values) {
            addCriterion("PayPalPass in", values, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassNotIn(List<String> values) {
            addCriterion("PayPalPass not in", values, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassBetween(String value1, String value2) {
            addCriterion("PayPalPass between", value1, value2, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andPaypalpassNotBetween(String value1, String value2) {
            addCriterion("PayPalPass not between", value1, value2, "paypalpass");
            return (Criteria) this;
        }

        public Criteria andFrontnameIsNull() {
            addCriterion("FrontName is null");
            return (Criteria) this;
        }

        public Criteria andFrontnameIsNotNull() {
            addCriterion("FrontName is not null");
            return (Criteria) this;
        }

        public Criteria andFrontnameEqualTo(String value) {
            addCriterion("FrontName =", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameNotEqualTo(String value) {
            addCriterion("FrontName <>", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameGreaterThan(String value) {
            addCriterion("FrontName >", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameGreaterThanOrEqualTo(String value) {
            addCriterion("FrontName >=", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameLessThan(String value) {
            addCriterion("FrontName <", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameLessThanOrEqualTo(String value) {
            addCriterion("FrontName <=", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameLike(String value) {
            addCriterion("FrontName like", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameNotLike(String value) {
            addCriterion("FrontName not like", value, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameIn(List<String> values) {
            addCriterion("FrontName in", values, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameNotIn(List<String> values) {
            addCriterion("FrontName not in", values, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameBetween(String value1, String value2) {
            addCriterion("FrontName between", value1, value2, "frontname");
            return (Criteria) this;
        }

        public Criteria andFrontnameNotBetween(String value1, String value2) {
            addCriterion("FrontName not between", value1, value2, "frontname");
            return (Criteria) this;
        }

        public Criteria andMacadrIsNull() {
            addCriterion("MacAdr is null");
            return (Criteria) this;
        }

        public Criteria andMacadrIsNotNull() {
            addCriterion("MacAdr is not null");
            return (Criteria) this;
        }

        public Criteria andMacadrEqualTo(String value) {
            addCriterion("MacAdr =", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrNotEqualTo(String value) {
            addCriterion("MacAdr <>", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrGreaterThan(String value) {
            addCriterion("MacAdr >", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrGreaterThanOrEqualTo(String value) {
            addCriterion("MacAdr >=", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrLessThan(String value) {
            addCriterion("MacAdr <", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrLessThanOrEqualTo(String value) {
            addCriterion("MacAdr <=", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrLike(String value) {
            addCriterion("MacAdr like", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrNotLike(String value) {
            addCriterion("MacAdr not like", value, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrIn(List<String> values) {
            addCriterion("MacAdr in", values, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrNotIn(List<String> values) {
            addCriterion("MacAdr not in", values, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrBetween(String value1, String value2) {
            addCriterion("MacAdr between", value1, value2, "macadr");
            return (Criteria) this;
        }

        public Criteria andMacadrNotBetween(String value1, String value2) {
            addCriterion("MacAdr not between", value1, value2, "macadr");
            return (Criteria) this;
        }

        public Criteria andSiteidIsNull() {
            addCriterion("SiteID is null");
            return (Criteria) this;
        }

        public Criteria andSiteidIsNotNull() {
            addCriterion("SiteID is not null");
            return (Criteria) this;
        }

        public Criteria andSiteidEqualTo(String value) {
            addCriterion("SiteID =", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidNotEqualTo(String value) {
            addCriterion("SiteID <>", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidGreaterThan(String value) {
            addCriterion("SiteID >", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidGreaterThanOrEqualTo(String value) {
            addCriterion("SiteID >=", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidLessThan(String value) {
            addCriterion("SiteID <", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidLessThanOrEqualTo(String value) {
            addCriterion("SiteID <=", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidLike(String value) {
            addCriterion("SiteID like", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidNotLike(String value) {
            addCriterion("SiteID not like", value, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidIn(List<String> values) {
            addCriterion("SiteID in", values, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidNotIn(List<String> values) {
            addCriterion("SiteID not in", values, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidBetween(String value1, String value2) {
            addCriterion("SiteID between", value1, value2, "siteid");
            return (Criteria) this;
        }

        public Criteria andSiteidNotBetween(String value1, String value2) {
            addCriterion("SiteID not between", value1, value2, "siteid");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeIsNull() {
            addCriterion("CurrencyType is null");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeIsNotNull() {
            addCriterion("CurrencyType is not null");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeEqualTo(String value) {
            addCriterion("CurrencyType =", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeNotEqualTo(String value) {
            addCriterion("CurrencyType <>", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeGreaterThan(String value) {
            addCriterion("CurrencyType >", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeGreaterThanOrEqualTo(String value) {
            addCriterion("CurrencyType >=", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeLessThan(String value) {
            addCriterion("CurrencyType <", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeLessThanOrEqualTo(String value) {
            addCriterion("CurrencyType <=", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeLike(String value) {
            addCriterion("CurrencyType like", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeNotLike(String value) {
            addCriterion("CurrencyType not like", value, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeIn(List<String> values) {
            addCriterion("CurrencyType in", values, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeNotIn(List<String> values) {
            addCriterion("CurrencyType not in", values, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeBetween(String value1, String value2) {
            addCriterion("CurrencyType between", value1, value2, "currencytype");
            return (Criteria) this;
        }

        public Criteria andCurrencytypeNotBetween(String value1, String value2) {
            addCriterion("CurrencyType not between", value1, value2, "currencytype");
            return (Criteria) this;
        }

        public Criteria andBpostdelayIsNull() {
            addCriterion("bPostDelay is null");
            return (Criteria) this;
        }

        public Criteria andBpostdelayIsNotNull() {
            addCriterion("bPostDelay is not null");
            return (Criteria) this;
        }

        public Criteria andBpostdelayEqualTo(Byte value) {
            addCriterion("bPostDelay =", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayNotEqualTo(Byte value) {
            addCriterion("bPostDelay <>", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayGreaterThan(Byte value) {
            addCriterion("bPostDelay >", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayGreaterThanOrEqualTo(Byte value) {
            addCriterion("bPostDelay >=", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayLessThan(Byte value) {
            addCriterion("bPostDelay <", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayLessThanOrEqualTo(Byte value) {
            addCriterion("bPostDelay <=", value, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayIn(List<Byte> values) {
            addCriterion("bPostDelay in", values, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayNotIn(List<Byte> values) {
            addCriterion("bPostDelay not in", values, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayBetween(Byte value1, Byte value2) {
            addCriterion("bPostDelay between", value1, value2, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andBpostdelayNotBetween(Byte value1, Byte value2) {
            addCriterion("bPostDelay not between", value1, value2, "bpostdelay");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeIsNull() {
            addCriterion("PostDelayTime is null");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeIsNotNull() {
            addCriterion("PostDelayTime is not null");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeEqualTo(Integer value) {
            addCriterion("PostDelayTime =", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeNotEqualTo(Integer value) {
            addCriterion("PostDelayTime <>", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeGreaterThan(Integer value) {
            addCriterion("PostDelayTime >", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("PostDelayTime >=", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeLessThan(Integer value) {
            addCriterion("PostDelayTime <", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeLessThanOrEqualTo(Integer value) {
            addCriterion("PostDelayTime <=", value, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeIn(List<Integer> values) {
            addCriterion("PostDelayTime in", values, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeNotIn(List<Integer> values) {
            addCriterion("PostDelayTime not in", values, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeBetween(Integer value1, Integer value2) {
            addCriterion("PostDelayTime between", value1, value2, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andPostdelaytimeNotBetween(Integer value1, Integer value2) {
            addCriterion("PostDelayTime not between", value1, value2, "postdelaytime");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayIsNull() {
            addCriterion("bWaitUnPay is null");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayIsNotNull() {
            addCriterion("bWaitUnPay is not null");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayEqualTo(Byte value) {
            addCriterion("bWaitUnPay =", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayNotEqualTo(Byte value) {
            addCriterion("bWaitUnPay <>", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayGreaterThan(Byte value) {
            addCriterion("bWaitUnPay >", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayGreaterThanOrEqualTo(Byte value) {
            addCriterion("bWaitUnPay >=", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayLessThan(Byte value) {
            addCriterion("bWaitUnPay <", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayLessThanOrEqualTo(Byte value) {
            addCriterion("bWaitUnPay <=", value, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayIn(List<Byte> values) {
            addCriterion("bWaitUnPay in", values, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayNotIn(List<Byte> values) {
            addCriterion("bWaitUnPay not in", values, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayBetween(Byte value1, Byte value2) {
            addCriterion("bWaitUnPay between", value1, value2, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andBwaitunpayNotBetween(Byte value1, Byte value2) {
            addCriterion("bWaitUnPay not between", value1, value2, "bwaitunpay");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeIsNull() {
            addCriterion("WaitUnpayTime is null");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeIsNotNull() {
            addCriterion("WaitUnpayTime is not null");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeEqualTo(BigDecimal value) {
            addCriterion("WaitUnpayTime =", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeNotEqualTo(BigDecimal value) {
            addCriterion("WaitUnpayTime <>", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeGreaterThan(BigDecimal value) {
            addCriterion("WaitUnpayTime >", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("WaitUnpayTime >=", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeLessThan(BigDecimal value) {
            addCriterion("WaitUnpayTime <", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("WaitUnpayTime <=", value, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeIn(List<BigDecimal> values) {
            addCriterion("WaitUnpayTime in", values, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeNotIn(List<BigDecimal> values) {
            addCriterion("WaitUnpayTime not in", values, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("WaitUnpayTime between", value1, value2, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andWaitunpaytimeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("WaitUnpayTime not between", value1, value2, "waitunpaytime");
            return (Criteria) this;
        }

        public Criteria andBgrmIsNull() {
            addCriterion("bGRM is null");
            return (Criteria) this;
        }

        public Criteria andBgrmIsNotNull() {
            addCriterion("bGRM is not null");
            return (Criteria) this;
        }

        public Criteria andBgrmEqualTo(Byte value) {
            addCriterion("bGRM =", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmNotEqualTo(Byte value) {
            addCriterion("bGRM <>", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmGreaterThan(Byte value) {
            addCriterion("bGRM >", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmGreaterThanOrEqualTo(Byte value) {
            addCriterion("bGRM >=", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmLessThan(Byte value) {
            addCriterion("bGRM <", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmLessThanOrEqualTo(Byte value) {
            addCriterion("bGRM <=", value, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmIn(List<Byte> values) {
            addCriterion("bGRM in", values, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmNotIn(List<Byte> values) {
            addCriterion("bGRM not in", values, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmBetween(Byte value1, Byte value2) {
            addCriterion("bGRM between", value1, value2, "bgrm");
            return (Criteria) this;
        }

        public Criteria andBgrmNotBetween(Byte value1, Byte value2) {
            addCriterion("bGRM not between", value1, value2, "bgrm");
            return (Criteria) this;
        }

        public Criteria andGrmcontentIsNull() {
            addCriterion("GRMContent is null");
            return (Criteria) this;
        }

        public Criteria andGrmcontentIsNotNull() {
            addCriterion("GRMContent is not null");
            return (Criteria) this;
        }

        public Criteria andGrmcontentEqualTo(String value) {
            addCriterion("GRMContent =", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentNotEqualTo(String value) {
            addCriterion("GRMContent <>", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentGreaterThan(String value) {
            addCriterion("GRMContent >", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentGreaterThanOrEqualTo(String value) {
            addCriterion("GRMContent >=", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentLessThan(String value) {
            addCriterion("GRMContent <", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentLessThanOrEqualTo(String value) {
            addCriterion("GRMContent <=", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentLike(String value) {
            addCriterion("GRMContent like", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentNotLike(String value) {
            addCriterion("GRMContent not like", value, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentIn(List<String> values) {
            addCriterion("GRMContent in", values, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentNotIn(List<String> values) {
            addCriterion("GRMContent not in", values, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentBetween(String value1, String value2) {
            addCriterion("GRMContent between", value1, value2, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andGrmcontentNotBetween(String value1, String value2) {
            addCriterion("GRMContent not between", value1, value2, "grmcontent");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointIsNull() {
            addCriterion("OrderTimePoint is null");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointIsNotNull() {
            addCriterion("OrderTimePoint is not null");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointEqualTo(String value) {
            addCriterion("OrderTimePoint =", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointNotEqualTo(String value) {
            addCriterion("OrderTimePoint <>", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointGreaterThan(String value) {
            addCriterion("OrderTimePoint >", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointGreaterThanOrEqualTo(String value) {
            addCriterion("OrderTimePoint >=", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointLessThan(String value) {
            addCriterion("OrderTimePoint <", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointLessThanOrEqualTo(String value) {
            addCriterion("OrderTimePoint <=", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointLike(String value) {
            addCriterion("OrderTimePoint like", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointNotLike(String value) {
            addCriterion("OrderTimePoint not like", value, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointIn(List<String> values) {
            addCriterion("OrderTimePoint in", values, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointNotIn(List<String> values) {
            addCriterion("OrderTimePoint not in", values, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointBetween(String value1, String value2) {
            addCriterion("OrderTimePoint between", value1, value2, "ordertimepoint");
            return (Criteria) this;
        }

        public Criteria andOrdertimepointNotBetween(String value1, String value2) {
            addCriterion("OrderTimePoint not between", value1, value2, "ordertimepoint");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}