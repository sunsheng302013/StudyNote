package com.taotao.pojo;

public class GCfgSpeclist {
    private Integer recid;

    private Integer spectype;

    private String specname;

    private Integer orderpos;

    private String speccode;

    public Integer getRecid() {
        return recid;
    }

    public void setRecid(Integer recid) {
        this.recid = recid;
    }

    public Integer getSpectype() {
        return spectype;
    }

    public void setSpectype(Integer spectype) {
        this.spectype = spectype;
    }

    public String getSpecname() {
        return specname;
    }

    public void setSpecname(String specname) {
        this.specname = specname == null ? null : specname.trim();
    }

    public Integer getOrderpos() {
        return orderpos;
    }

    public void setOrderpos(Integer orderpos) {
        this.orderpos = orderpos;
    }

    public String getSpeccode() {
        return speccode;
    }

    public void setSpeccode(String speccode) {
        this.speccode = speccode == null ? null : speccode.trim();
    }
}