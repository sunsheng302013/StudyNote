package com.taotao.pojo;

import java.util.ArrayList;
import java.util.List;

public class GCfgWarehouselistExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public GCfgWarehouselistExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andWarehouseidIsNull() {
            addCriterion("WarehouseID is null");
            return (Criteria) this;
        }

        public Criteria andWarehouseidIsNotNull() {
            addCriterion("WarehouseID is not null");
            return (Criteria) this;
        }

        public Criteria andWarehouseidEqualTo(Integer value) {
            addCriterion("WarehouseID =", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotEqualTo(Integer value) {
            addCriterion("WarehouseID <>", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidGreaterThan(Integer value) {
            addCriterion("WarehouseID >", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidGreaterThanOrEqualTo(Integer value) {
            addCriterion("WarehouseID >=", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidLessThan(Integer value) {
            addCriterion("WarehouseID <", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidLessThanOrEqualTo(Integer value) {
            addCriterion("WarehouseID <=", value, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidIn(List<Integer> values) {
            addCriterion("WarehouseID in", values, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotIn(List<Integer> values) {
            addCriterion("WarehouseID not in", values, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidBetween(Integer value1, Integer value2) {
            addCriterion("WarehouseID between", value1, value2, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehouseidNotBetween(Integer value1, Integer value2) {
            addCriterion("WarehouseID not between", value1, value2, "warehouseid");
            return (Criteria) this;
        }

        public Criteria andWarehousenameIsNull() {
            addCriterion("WarehouseName is null");
            return (Criteria) this;
        }

        public Criteria andWarehousenameIsNotNull() {
            addCriterion("WarehouseName is not null");
            return (Criteria) this;
        }

        public Criteria andWarehousenameEqualTo(String value) {
            addCriterion("WarehouseName =", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameNotEqualTo(String value) {
            addCriterion("WarehouseName <>", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameGreaterThan(String value) {
            addCriterion("WarehouseName >", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameGreaterThanOrEqualTo(String value) {
            addCriterion("WarehouseName >=", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameLessThan(String value) {
            addCriterion("WarehouseName <", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameLessThanOrEqualTo(String value) {
            addCriterion("WarehouseName <=", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameLike(String value) {
            addCriterion("WarehouseName like", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameNotLike(String value) {
            addCriterion("WarehouseName not like", value, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameIn(List<String> values) {
            addCriterion("WarehouseName in", values, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameNotIn(List<String> values) {
            addCriterion("WarehouseName not in", values, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameBetween(String value1, String value2) {
            addCriterion("WarehouseName between", value1, value2, "warehousename");
            return (Criteria) this;
        }

        public Criteria andWarehousenameNotBetween(String value1, String value2) {
            addCriterion("WarehouseName not between", value1, value2, "warehousename");
            return (Criteria) this;
        }

        public Criteria andOrderposIsNull() {
            addCriterion("OrderPos is null");
            return (Criteria) this;
        }

        public Criteria andOrderposIsNotNull() {
            addCriterion("OrderPos is not null");
            return (Criteria) this;
        }

        public Criteria andOrderposEqualTo(Integer value) {
            addCriterion("OrderPos =", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotEqualTo(Integer value) {
            addCriterion("OrderPos <>", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposGreaterThan(Integer value) {
            addCriterion("OrderPos >", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposGreaterThanOrEqualTo(Integer value) {
            addCriterion("OrderPos >=", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposLessThan(Integer value) {
            addCriterion("OrderPos <", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposLessThanOrEqualTo(Integer value) {
            addCriterion("OrderPos <=", value, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposIn(List<Integer> values) {
            addCriterion("OrderPos in", values, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotIn(List<Integer> values) {
            addCriterion("OrderPos not in", values, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposBetween(Integer value1, Integer value2) {
            addCriterion("OrderPos between", value1, value2, "orderpos");
            return (Criteria) this;
        }

        public Criteria andOrderposNotBetween(Integer value1, Integer value2) {
            addCriterion("OrderPos not between", value1, value2, "orderpos");
            return (Criteria) this;
        }

        public Criteria andBblockupIsNull() {
            addCriterion("bBlockUp is null");
            return (Criteria) this;
        }

        public Criteria andBblockupIsNotNull() {
            addCriterion("bBlockUp is not null");
            return (Criteria) this;
        }

        public Criteria andBblockupEqualTo(Boolean value) {
            addCriterion("bBlockUp =", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotEqualTo(Boolean value) {
            addCriterion("bBlockUp <>", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupGreaterThan(Boolean value) {
            addCriterion("bBlockUp >", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupGreaterThanOrEqualTo(Boolean value) {
            addCriterion("bBlockUp >=", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupLessThan(Boolean value) {
            addCriterion("bBlockUp <", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupLessThanOrEqualTo(Boolean value) {
            addCriterion("bBlockUp <=", value, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupIn(List<Boolean> values) {
            addCriterion("bBlockUp in", values, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotIn(List<Boolean> values) {
            addCriterion("bBlockUp not in", values, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupBetween(Boolean value1, Boolean value2) {
            addCriterion("bBlockUp between", value1, value2, "bblockup");
            return (Criteria) this;
        }

        public Criteria andBblockupNotBetween(Boolean value1, Boolean value2) {
            addCriterion("bBlockUp not between", value1, value2, "bblockup");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeIsNull() {
            addCriterion("WarehouseType is null");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeIsNotNull() {
            addCriterion("WarehouseType is not null");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeEqualTo(Integer value) {
            addCriterion("WarehouseType =", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeNotEqualTo(Integer value) {
            addCriterion("WarehouseType <>", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeGreaterThan(Integer value) {
            addCriterion("WarehouseType >", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("WarehouseType >=", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeLessThan(Integer value) {
            addCriterion("WarehouseType <", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeLessThanOrEqualTo(Integer value) {
            addCriterion("WarehouseType <=", value, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeIn(List<Integer> values) {
            addCriterion("WarehouseType in", values, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeNotIn(List<Integer> values) {
            addCriterion("WarehouseType not in", values, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeBetween(Integer value1, Integer value2) {
            addCriterion("WarehouseType between", value1, value2, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andWarehousetypeNotBetween(Integer value1, Integer value2) {
            addCriterion("WarehouseType not between", value1, value2, "warehousetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeIsNull() {
            addCriterion("InterfaceType is null");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeIsNotNull() {
            addCriterion("InterfaceType is not null");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeEqualTo(String value) {
            addCriterion("InterfaceType =", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeNotEqualTo(String value) {
            addCriterion("InterfaceType <>", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeGreaterThan(String value) {
            addCriterion("InterfaceType >", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeGreaterThanOrEqualTo(String value) {
            addCriterion("InterfaceType >=", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeLessThan(String value) {
            addCriterion("InterfaceType <", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeLessThanOrEqualTo(String value) {
            addCriterion("InterfaceType <=", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeLike(String value) {
            addCriterion("InterfaceType like", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeNotLike(String value) {
            addCriterion("InterfaceType not like", value, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeIn(List<String> values) {
            addCriterion("InterfaceType in", values, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeNotIn(List<String> values) {
            addCriterion("InterfaceType not in", values, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeBetween(String value1, String value2) {
            addCriterion("InterfaceType between", value1, value2, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andInterfacetypeNotBetween(String value1, String value2) {
            addCriterion("InterfaceType not between", value1, value2, "interfacetype");
            return (Criteria) this;
        }

        public Criteria andCountryIsNull() {
            addCriterion("Country is null");
            return (Criteria) this;
        }

        public Criteria andCountryIsNotNull() {
            addCriterion("Country is not null");
            return (Criteria) this;
        }

        public Criteria andCountryEqualTo(String value) {
            addCriterion("Country =", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotEqualTo(String value) {
            addCriterion("Country <>", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThan(String value) {
            addCriterion("Country >", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThanOrEqualTo(String value) {
            addCriterion("Country >=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThan(String value) {
            addCriterion("Country <", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThanOrEqualTo(String value) {
            addCriterion("Country <=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLike(String value) {
            addCriterion("Country like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotLike(String value) {
            addCriterion("Country not like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryIn(List<String> values) {
            addCriterion("Country in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotIn(List<String> values) {
            addCriterion("Country not in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryBetween(String value1, String value2) {
            addCriterion("Country between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotBetween(String value1, String value2) {
            addCriterion("Country not between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNull() {
            addCriterion("Province is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNotNull() {
            addCriterion("Province is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceEqualTo(String value) {
            addCriterion("Province =", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotEqualTo(String value) {
            addCriterion("Province <>", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThan(String value) {
            addCriterion("Province >", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThanOrEqualTo(String value) {
            addCriterion("Province >=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThan(String value) {
            addCriterion("Province <", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThanOrEqualTo(String value) {
            addCriterion("Province <=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLike(String value) {
            addCriterion("Province like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotLike(String value) {
            addCriterion("Province not like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceIn(List<String> values) {
            addCriterion("Province in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotIn(List<String> values) {
            addCriterion("Province not in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceBetween(String value1, String value2) {
            addCriterion("Province between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotBetween(String value1, String value2) {
            addCriterion("Province not between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("City is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("City is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("City =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("City <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("City >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("City >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("City <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("City <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("City like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("City not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("City in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("City not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("City between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("City not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andTownIsNull() {
            addCriterion("Town is null");
            return (Criteria) this;
        }

        public Criteria andTownIsNotNull() {
            addCriterion("Town is not null");
            return (Criteria) this;
        }

        public Criteria andTownEqualTo(String value) {
            addCriterion("Town =", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotEqualTo(String value) {
            addCriterion("Town <>", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownGreaterThan(String value) {
            addCriterion("Town >", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownGreaterThanOrEqualTo(String value) {
            addCriterion("Town >=", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLessThan(String value) {
            addCriterion("Town <", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLessThanOrEqualTo(String value) {
            addCriterion("Town <=", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownLike(String value) {
            addCriterion("Town like", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotLike(String value) {
            addCriterion("Town not like", value, "town");
            return (Criteria) this;
        }

        public Criteria andTownIn(List<String> values) {
            addCriterion("Town in", values, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotIn(List<String> values) {
            addCriterion("Town not in", values, "town");
            return (Criteria) this;
        }

        public Criteria andTownBetween(String value1, String value2) {
            addCriterion("Town between", value1, value2, "town");
            return (Criteria) this;
        }

        public Criteria andTownNotBetween(String value1, String value2) {
            addCriterion("Town not between", value1, value2, "town");
            return (Criteria) this;
        }

        public Criteria andAdrIsNull() {
            addCriterion("Adr is null");
            return (Criteria) this;
        }

        public Criteria andAdrIsNotNull() {
            addCriterion("Adr is not null");
            return (Criteria) this;
        }

        public Criteria andAdrEqualTo(String value) {
            addCriterion("Adr =", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotEqualTo(String value) {
            addCriterion("Adr <>", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrGreaterThan(String value) {
            addCriterion("Adr >", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrGreaterThanOrEqualTo(String value) {
            addCriterion("Adr >=", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLessThan(String value) {
            addCriterion("Adr <", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLessThanOrEqualTo(String value) {
            addCriterion("Adr <=", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrLike(String value) {
            addCriterion("Adr like", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotLike(String value) {
            addCriterion("Adr not like", value, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrIn(List<String> values) {
            addCriterion("Adr in", values, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotIn(List<String> values) {
            addCriterion("Adr not in", values, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrBetween(String value1, String value2) {
            addCriterion("Adr between", value1, value2, "adr");
            return (Criteria) this;
        }

        public Criteria andAdrNotBetween(String value1, String value2) {
            addCriterion("Adr not between", value1, value2, "adr");
            return (Criteria) this;
        }

        public Criteria andTelIsNull() {
            addCriterion("Tel is null");
            return (Criteria) this;
        }

        public Criteria andTelIsNotNull() {
            addCriterion("Tel is not null");
            return (Criteria) this;
        }

        public Criteria andTelEqualTo(String value) {
            addCriterion("Tel =", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotEqualTo(String value) {
            addCriterion("Tel <>", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThan(String value) {
            addCriterion("Tel >", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThanOrEqualTo(String value) {
            addCriterion("Tel >=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThan(String value) {
            addCriterion("Tel <", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThanOrEqualTo(String value) {
            addCriterion("Tel <=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLike(String value) {
            addCriterion("Tel like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotLike(String value) {
            addCriterion("Tel not like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelIn(List<String> values) {
            addCriterion("Tel in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotIn(List<String> values) {
            addCriterion("Tel not in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelBetween(String value1, String value2) {
            addCriterion("Tel between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotBetween(String value1, String value2) {
            addCriterion("Tel not between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andLinkmanIsNull() {
            addCriterion("LinkMan is null");
            return (Criteria) this;
        }

        public Criteria andLinkmanIsNotNull() {
            addCriterion("LinkMan is not null");
            return (Criteria) this;
        }

        public Criteria andLinkmanEqualTo(String value) {
            addCriterion("LinkMan =", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotEqualTo(String value) {
            addCriterion("LinkMan <>", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanGreaterThan(String value) {
            addCriterion("LinkMan >", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanGreaterThanOrEqualTo(String value) {
            addCriterion("LinkMan >=", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLessThan(String value) {
            addCriterion("LinkMan <", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLessThanOrEqualTo(String value) {
            addCriterion("LinkMan <=", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanLike(String value) {
            addCriterion("LinkMan like", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotLike(String value) {
            addCriterion("LinkMan not like", value, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanIn(List<String> values) {
            addCriterion("LinkMan in", values, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotIn(List<String> values) {
            addCriterion("LinkMan not in", values, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanBetween(String value1, String value2) {
            addCriterion("LinkMan between", value1, value2, "linkman");
            return (Criteria) this;
        }

        public Criteria andLinkmanNotBetween(String value1, String value2) {
            addCriterion("LinkMan not between", value1, value2, "linkman");
            return (Criteria) this;
        }

        public Criteria andZipIsNull() {
            addCriterion("Zip is null");
            return (Criteria) this;
        }

        public Criteria andZipIsNotNull() {
            addCriterion("Zip is not null");
            return (Criteria) this;
        }

        public Criteria andZipEqualTo(String value) {
            addCriterion("Zip =", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotEqualTo(String value) {
            addCriterion("Zip <>", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThan(String value) {
            addCriterion("Zip >", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThanOrEqualTo(String value) {
            addCriterion("Zip >=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThan(String value) {
            addCriterion("Zip <", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThanOrEqualTo(String value) {
            addCriterion("Zip <=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLike(String value) {
            addCriterion("Zip like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotLike(String value) {
            addCriterion("Zip not like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipIn(List<String> values) {
            addCriterion("Zip in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotIn(List<String> values) {
            addCriterion("Zip not in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipBetween(String value1, String value2) {
            addCriterion("Zip between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotBetween(String value1, String value2) {
            addCriterion("Zip not between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andBnegativestockIsNull() {
            addCriterion("bNegativeStock is null");
            return (Criteria) this;
        }

        public Criteria andBnegativestockIsNotNull() {
            addCriterion("bNegativeStock is not null");
            return (Criteria) this;
        }

        public Criteria andBnegativestockEqualTo(Byte value) {
            addCriterion("bNegativeStock =", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockNotEqualTo(Byte value) {
            addCriterion("bNegativeStock <>", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockGreaterThan(Byte value) {
            addCriterion("bNegativeStock >", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockGreaterThanOrEqualTo(Byte value) {
            addCriterion("bNegativeStock >=", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockLessThan(Byte value) {
            addCriterion("bNegativeStock <", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockLessThanOrEqualTo(Byte value) {
            addCriterion("bNegativeStock <=", value, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockIn(List<Byte> values) {
            addCriterion("bNegativeStock in", values, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockNotIn(List<Byte> values) {
            addCriterion("bNegativeStock not in", values, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockBetween(Byte value1, Byte value2) {
            addCriterion("bNegativeStock between", value1, value2, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBnegativestockNotBetween(Byte value1, Byte value2) {
            addCriterion("bNegativeStock not between", value1, value2, "bnegativestock");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsIsNull() {
            addCriterion("bAutoAddGoods is null");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsIsNotNull() {
            addCriterion("bAutoAddGoods is not null");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsEqualTo(Byte value) {
            addCriterion("bAutoAddGoods =", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsNotEqualTo(Byte value) {
            addCriterion("bAutoAddGoods <>", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsGreaterThan(Byte value) {
            addCriterion("bAutoAddGoods >", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsGreaterThanOrEqualTo(Byte value) {
            addCriterion("bAutoAddGoods >=", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsLessThan(Byte value) {
            addCriterion("bAutoAddGoods <", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsLessThanOrEqualTo(Byte value) {
            addCriterion("bAutoAddGoods <=", value, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsIn(List<Byte> values) {
            addCriterion("bAutoAddGoods in", values, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsNotIn(List<Byte> values) {
            addCriterion("bAutoAddGoods not in", values, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsBetween(Byte value1, Byte value2) {
            addCriterion("bAutoAddGoods between", value1, value2, "bautoaddgoods");
            return (Criteria) this;
        }

        public Criteria andBautoaddgoodsNotBetween(Byte value1, Byte value2) {
            addCriterion("bAutoAddGoods not between", value1, value2, "bautoaddgoods");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}