package com.taotao.mapper;

import com.taotao.pojo.GCfgShoplist;
import com.taotao.pojo.GCfgShoplistExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GCfgShoplistMapper {
    int countByExample(GCfgShoplistExample example);

    int deleteByExample(GCfgShoplistExample example);

    int deleteByPrimaryKey(Integer shopid);

    int insert(GCfgShoplist record);

    int insertSelective(GCfgShoplist record);

    List<GCfgShoplist> selectByExample(GCfgShoplistExample example);

    GCfgShoplist selectByPrimaryKey(Integer shopid);

    int updateByExampleSelective(@Param("record") GCfgShoplist record, @Param("example") GCfgShoplistExample example);

    int updateByExample(@Param("record") GCfgShoplist record, @Param("example") GCfgShoplistExample example);

    int updateByPrimaryKeySelective(GCfgShoplist record);

    int updateByPrimaryKey(GCfgShoplist record);
}