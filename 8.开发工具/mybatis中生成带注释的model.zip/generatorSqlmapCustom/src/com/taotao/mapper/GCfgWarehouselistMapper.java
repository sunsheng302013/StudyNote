package com.taotao.mapper;

import com.taotao.pojo.GCfgWarehouselist;
import com.taotao.pojo.GCfgWarehouselistExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GCfgWarehouselistMapper {
    int countByExample(GCfgWarehouselistExample example);

    int deleteByExample(GCfgWarehouselistExample example);

    int deleteByPrimaryKey(Integer warehouseid);

    int insert(GCfgWarehouselist record);

    int insertSelective(GCfgWarehouselist record);

    List<GCfgWarehouselist> selectByExample(GCfgWarehouselistExample example);

    GCfgWarehouselist selectByPrimaryKey(Integer warehouseid);

    int updateByExampleSelective(@Param("record") GCfgWarehouselist record, @Param("example") GCfgWarehouselistExample example);

    int updateByExample(@Param("record") GCfgWarehouselist record, @Param("example") GCfgWarehouselistExample example);

    int updateByPrimaryKeySelective(GCfgWarehouselist record);

    int updateByPrimaryKey(GCfgWarehouselist record);
}